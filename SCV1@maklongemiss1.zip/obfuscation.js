// ================= OBFUSCATION MODULE =================
// Modul untuk menangani semua fitur obfuscation dengan berbagai metode
// Dipindahkan dari script1 (sc_encrypt_dan_deploy)

const JsConfuser = require("js-confuser");
const crypto = require("crypto");
const fs = require("fs-extra");
const path = require("path");

// CONFIGURATION UNTUK SETIAP COMMAND
const getObfuscationConfig = (level = "high") => ({
    target: "node", compact: true, renameVariables: true, renameGlobals: true,
    identifierGenerator: "mangled", stringEncoding: true, stringSplitting: true,
    controlFlowFlattening: level === "high" ? 0.95 : level === "medium" ? 0.75 : 0.5,
    duplicateLiteralsRemoval: true, deadCode: true, calculator: true,
    opaquePredicates: true, lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true }
});

const getMandarinObfuscationConfig = () => {
    const mandarinChars = ["龙","虎","风","云","山","河","天","地","雷","电","火","水","木","金","土","星","月","日","光","影","峰","泉","林","海","雪","霜","雾","冰","焰","石"];
    const generateMandarinName = () => { let name = ""; for (let i = 0; i < 6; i++) name += mandarinChars[Math.floor(Math.random() * mandarinChars.length)]; return name; };
    return { target: "node", compact: true, renameVariables: true, renameGlobals: true, identifierGenerator: generateMandarinName, stringEncoding: true, stringSplitting: true, controlFlowFlattening: 0.95, duplicateLiteralsRemoval: true, deadCode: true, calculator: true, opaquePredicates: true, lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true } };
};

const getArabObfuscationConfig = () => {
    const arabicChars = ["أ","ب","ت","ث","ج","ح","خ","د","ذ","ر","ز","س","ش","ص","ض","ط","ظ","ع","غ","ف","ق","ك","ل","م","ن","ه","و","ي"];
    const generateArabicName = () => { let name = ""; for (let i = 0; i < 6; i++) name += arabicChars[Math.floor(Math.random() * arabicChars.length)]; return name; };
    return { target: "node", compact: true, renameVariables: true, renameGlobals: true, identifierGenerator: generateArabicName, stringEncoding: true, stringSplitting: true, controlFlowFlattening: 0.95, duplicateLiteralsRemoval: true, deadCode: true, calculator: true, opaquePredicates: true, lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true } };
};

const getJapanObfuscationConfig = () => {
    const japaneseChars = ["あ","い","う","え","お","か","き","く","け","こ","さ","し","す","せ","そ","た","ち","つ","て","と","な","に","ぬ","ね","の","は","ひ","ふ","へ","ほ","ま","み","む","め","も","や","ゆ","よ","ら","り","る","れ","ろ","わ","を","ん"];
    const generateJapaneseName = () => { let name = ""; for (let i = 0; i < 6; i++) name += japaneseChars[Math.floor(Math.random() * japaneseChars.length)]; return name; };
    return { target: "node", compact: true, renameVariables: true, renameGlobals: true, identifierGenerator: generateJapaneseName, stringEncoding: true, stringSplitting: true, controlFlowFlattening: 0.9, flatten: true, duplicateLiteralsRemoval: true, deadCode: true, calculator: true, opaquePredicates: true, lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true } };
};

const getInvisObfuscationConfig = () => {
    const generateInvisName = () => { let name = ""; for (let i = 0; i < 5; i++) name += "_"; return name + Math.random().toString(36).substring(2, 6); };
    return { target: "node", compact: true, renameVariables: true, renameGlobals: true, identifierGenerator: generateInvisName, stringEncoding: true, stringSplitting: true, controlFlowFlattening: 0.95, duplicateLiteralsRemoval: true, deadCode: true, calculator: true, opaquePredicates: true, lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true } };
};

const getJapanxArabObfuscationConfig = () => {
    const chars = ["あ","い","う","え","お","か","き","く","け","こ","さ","し","す","せ","そ","た","ち","つ","て","と","な","に","ぬ","ね","の","は","ひ","ふ","へ","ほ","ま","み","む","め","も","や","ゆ","よ","أ","ب","ت","ث","ج","ح","خ","د","ذ","ر","ز","س","ش","ص","ض","ط","ظ","ع","غ","ف","ق","ك","ل","م","ن","ه","و","ي","ら","り","る","れ","ろ","わ","を","ん"];
    const generateName = () => { let name = ""; for (let i = 0; i < 6; i++) name += chars[Math.floor(Math.random() * chars.length)]; return name; };
    return { target: "node", compact: true, renameVariables: true, renameGlobals: true, identifierGenerator: generateName, stringEncoding: true, stringSplitting: true, controlFlowFlattening: 0.95, flatten: true, duplicateLiteralsRemoval: true, deadCode: true, calculator: true, opaquePredicates: true, lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true } };
};

const getXObfuscationConfig = () => {
    const generateXName = () => "xZ" + crypto.randomUUID().slice(0, 4);
    return { target: "node", compact: true, renameVariables: true, renameGlobals: true, identifierGenerator: generateXName, stringEncoding: true, stringSplitting: false, controlFlowFlattening: 0.5, flatten: true, opaquePredicates: true, lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true } };
};

const getNebulaObfuscationConfig = () => {
    const generateNebulaName = () => "NX" + Math.random().toString(36).substring(2, 8);
    return { target: "node", compact: true, renameVariables: true, renameGlobals: true, identifierGenerator: generateNebulaName, stringEncoding: true, controlFlowFlattening: 0.85, flatten: true, deadCode: true, opaquePredicates: true, lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true } };
};

const getNovaObfuscationConfig = () => {
    const generateNovaName = () => "nZ_" + crypto.randomBytes(4).toString('hex');
    return { target: "node", compact: true, renameVariables: true, renameGlobals: true, identifierGenerator: generateNovaName, stringEncoding: true, controlFlowFlattening: 0.9, flatten: true, lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true } };
};

const getSiuCalcrickObfuscationConfig = () => {
    const generateName = () => "Siu_" + Math.random().toString(36).substring(2, 10);
    return { target: "node", compact: true, renameVariables: true, renameGlobals: true, identifierGenerator: generateName, stringEncoding: true, stringSplitting: true, controlFlowFlattening: 0.95, deadCode: true, calculator: true, opaquePredicates: true, lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true } };
};

const getCustomObfuscationConfig = (customName) => {
    const generateCustomName = () => `${customName}_${Math.random().toString(36).substring(2, 8)}`;
    return { target: "node", compact: true, renameVariables: true, renameGlobals: true, identifierGenerator: generateCustomName, stringEncoding: true, stringSplitting: true, controlFlowFlattening: 0.75, duplicateLiteralsRemoval: true, deadCode: true, opaquePredicates: true, lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true } };
};

const getCustomV2ObfuscationConfig = (customName) => {
    const generateCustomV2Name = () => `${customName}_v2_${crypto.randomBytes(3).toString('hex')}`;
    return { target: "node", compact: true, renameVariables: true, renameGlobals: true, identifierGenerator: generateCustomV2Name, stringEncoding: true, stringSplitting: true, controlFlowFlattening: 0.85, flatten: true, deadCode: true, calculator: true, opaquePredicates: true, lock: { selfDefending: true, antiDebug: true, integrity: true, tamperProtection: true } };
};

// ================= OBFUSCATION HELPER FUNCTIONS =================

/**
 * Obfuscate JavaScript code dengan metode yang dipilih
 * @param {string} code - Kode JavaScript yang akan diobfuscate
 * @param {string} method - Metode obfuscation (standard, mandarin, arab, japan, invisbile, japan-arab, x, nebula, nova, siu, custom, customv2)
 * @param {string} customName - Nama custom untuk custom methods
 * @param {string} level - Level obfuscation (low, medium, high) - hanya untuk standard method
 * @returns {Promise<string>} - Kode yang sudah diobfuscate
 */
async function obfuscateCode(code, method = "standard", customName = "obf", level = "high") {
    let config;

    switch (method.toLowerCase()) {
        case "standard":
            config = getObfuscationConfig(level);
            break;
        case "mandarin":
            config = getMandarinObfuscationConfig();
            break;
        case "arab":
            config = getArabObfuscationConfig();
            break;
        case "japan":
            config = getJapanObfuscationConfig();
            break;
        case "invisible":
            config = getInvisObfuscationConfig();
            break;
        case "japan-arab":
            config = getJapanxArabObfuscationConfig();
            break;
        case "x":
            config = getXObfuscationConfig();
            break;
        case "nebula":
            config = getNebulaObfuscationConfig();
            break;
        case "nova":
            config = getNovaObfuscationConfig();
            break;
        case "siu":
            config = getSiuCalcrickObfuscationConfig();
            break;
        case "custom":
            config = getCustomObfuscationConfig(customName);
            break;
        case "customv2":
            config = getCustomV2ObfuscationConfig(customName);
            break;
        default:
            config = getObfuscationConfig(level);
    }

    try {
        const obfuscated = await JsConfuser.obfuscate(code, config);
        return obfuscated.code;
    } catch (error) {
        throw new Error(`Obfuscation failed: ${error.message}`);
    }
}

/**
 * Obfuscate file JavaScript
 * @param {string} filePath - Path ke file JavaScript
 * @param {string} outputPath - Path output untuk file yang diobfuscate
 * @param {string} method - Metode obfuscation
 * @param {string} customName - Nama custom jika diperlukan
 * @param {string} level - Level obfuscation untuk standard method
 * @returns {Promise<string>} - Path ke file output
 */
async function obfuscateFile(filePath, outputPath, method = "standard", customName = "obf", level = "high") {
    const fileContent = await fs.readFile(filePath, "utf-8");
    const obfuscatedCode = await obfuscateCode(fileContent, method, customName, level);
    await fs.writeFile(outputPath, obfuscatedCode);
    return outputPath;
}

/**
 * Validasi kode obfuscate dengan mencoba menjalankannya
 * @param {string} code - Kode yang akan divalidasi
 * @returns {boolean} - True jika valid, false jika error
 */
function validateObfuscatedCode(code) {
    try {
        new Function(code);
        return true;
    } catch (error) {
        console.error("Validation error:", error.message);
        return false;
    }
}

// ================= EXPORTS =================

module.exports = {
    // Config generators
    getObfuscationConfig,
    getMandarinObfuscationConfig,
    getArabObfuscationConfig,
    getJapanObfuscationConfig,
    getInvisObfuscationConfig,
    getJapanxArabObfuscationConfig,
    getXObfuscationConfig,
    getNebulaObfuscationConfig,
    getNovaObfuscationConfig,
    getSiuCalcrickObfuscationConfig,
    getCustomObfuscationConfig,
    getCustomV2ObfuscationConfig,

    // Helper functions
    obfuscateCode,
    obfuscateFile,
    validateObfuscatedCode
};
