// index.js - Flutter Build Bot (GramJS + GitHub Actions)

const { TelegramClient, Api } = require("telegram");
const { StringSession } = require("telegram/sessions");
const { NewMessage } = require("telegram/events");
const { CallbackQuery } = require("telegram/events/CallbackQuery");
const { Button } = require("telegram/tl/custom/button");
const fs = require("fs");
const path = require("path");
const AdmZip = require("adm-zip");
const os = require("os");
const { execSync } = require("child_process");
const net = require("net");

const CONFIG = require("./config");
const {
  getUserJob,
  setUserJob,
  removeUserJob,
  isUserBuilding,
  getActiveJobs,
  getQueueStats,
} = require("./queue");
const {
  githubRequest,
  uploadZipToRelease,
  deleteRelease,
  triggerWorkflow,
  getRunStatus,
  getArtifacts,
  downloadArtifactZip,
  getFailedStepLog,
  sleep,
  createReleaseOnly,
  uploadAssetFile,
  triggerWeb2ApkWorkflow,
  publishRelease,
} = require("./github");
const {
  getObfuscationConfig,
  getMandarinObfuscationConfig,
  getArabObfuscationConfig,
  getJapanObfuscationConfig,
  getInvisObfuscationConfig,
  getJapanxArabObfuscationConfig,
  getXObfuscationConfig,
  getNebulaObfuscationConfig,
  getNovaObfuscationConfig,
  getSiuCalcrickObfuscationConfig,
  getCustomObfuscationConfig,
  getCustomV2ObfuscationConfig,
  obfuscateCode,
  obfuscateFile,
  validateObfuscatedCode,
} = require("./obfuscation");

// ─── CLIENT SETUP ────────────────────────────────────────────────────────────
const SESSION_FILE = "./session.txt";
const sessionString = fs.existsSync(SESSION_FILE)
  ? fs.readFileSync(SESSION_FILE, "utf8").trim()
  : "";

const API_ID = parseInt(process.env.API_ID || "37597865");
const API_HASH = process.env.API_HASH || "e7ef563fdf51850d02ae24ee56bd3a69";

const client = new TelegramClient(new StringSession(sessionString), API_ID, API_HASH, {
  connectionRetries: 5,
});

// State memory untuk melacak alur pengisian laporan user
const userStates = new Map();

// ─── UTILS & DATABASE ────────────────────────────────────────────────────────
function isAdmin(userId) {
  return CONFIG.ADMIN_IDS.includes(Number(userId));
}

const DB_PATH = "./users.json";
const STATS_PATH = "./stats.json";

if (!fs.existsSync(DB_PATH)) {
  fs.writeFileSync(DB_PATH, JSON.stringify([]));
}

const db = {
  // ─── USER MANAGEMENT (BAWAAN LU) ──────────────────────────────────────────
  upsertUser: (userData) => {
    const data = JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
    const index = data.findIndex((u) => u.userId === userData.userId);
    if (index !== -1) {
      data[index] = { ...data[index], ...userData, lastActive: new Date() };
    } else {
      data.push({ ...userData, joinedAt: new Date() });
    }
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
    return index === -1;
  },

  getAllUsers: () => {
    return JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
  },

  // ─── REPORT BLOCK SYSTEM (BAWAAN LU) ──────────────────────────────────────
  blockedReportUsers: new Set(),
  isReportBlocked(userId) {
    return this.blockedReportUsers.has(userId);
  },
  blockReportUser(userId) {
    this.blockedReportUsers.add(userId);
  },
  unblockReportUser(userId) {
    this.blockedReportUsers.delete(userId);
  },

  // ─── FITUR BARU: GLOBAL STATS MANAGEMENT ──────────────────────────────────
  // Fungsi untuk mengambil data statistik sukses & gagal saat ini
  getStats() {
    // Jika file stats.json belum ada, otomatis buatin baru dengan nilai awal 0
    if (!fs.existsSync(STATS_PATH)) {
      const initialStats = { success: 0, failed: 0 };
      fs.writeFileSync(STATS_PATH, JSON.stringify(initialStats, null, 2));
      return initialStats;
    }
    return JSON.parse(fs.readFileSync(STATS_PATH, "utf-8"));
  },

  // Fungsi untuk menambah hitungan +1 sukses atau gagal secara real-time
  incrementStat(type) {
    const stats = this.getStats();
    
    if (type === "success") stats.success += 1;
    if (type === "failed") stats.failed += 1;
    
    fs.writeFileSync(STATS_PATH, JSON.stringify(stats, null, 2));
    return stats; // Mengembalikan data statistik terbaru yang sudah di-update
  }
};

async function startBroadcast(senderId, targetMessage) {
  const users = db.getAllUsers();
  let success = 0;
  let failed = 0;

  for (const user of users) {
    try {
      await client.sendMessage(user.userId, {
        message: targetMessage.text,
        file: targetMessage.file || null,
      });
      success++;
    } catch (err) {
      failed++;
      console.log(`Gagal kirim ke ${user.userId}: ${err.message}`);
    }
    await new Promise((resolve) => setTimeout(resolve, 100));
  }

  return { success, failed };
}

function formatDuration(sec) {
  sec = Math.floor(sec);
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  const parts = [];
  if (h > 0) parts.push(`${h} Jam`);
  if (m > 0) parts.push(`${m} Menit`);
  if (s > 0 || parts.length === 0) parts.push(`${s} Detik`);
  return parts.join(" ");
}

function elapsedSec(since) {
  return Math.floor((Date.now() - since) / 1000);
}

function progressBar(pct) {
  const filled = Math.round(pct / 10);
  const bar = "█".repeat(filled) + "░".repeat(10 - filled);
  return bar;
}

function tmpPath(name) {
  return path.join(CONFIG.TMP_DIR, name);
}

function genTag(userId) {
  return `build-${userId}-${Date.now()}`;
}

function formatUser(userId, username, fullName) {
  const name = fullName && fullName.trim() && fullName !== "Unknown User"
    ? fullName.trim()
    : username
    ? username.replace("@", "")
    : "User";

  if (username) {
    const cleanUsername = username.startsWith("@") ? username : `@${username}`;
    return `${name}(${cleanUsername})`;
  }

  return name;
}

function buildButtons(rows) {
  return rows.map((row) =>
    row.map((btn) => {
      if (btn.url) return Button.url(btn.text, btn.url);
      return Button.inline(btn.text, Buffer.from(btn.data));
    })
  );
}

async function send(chatId, text, buttonDefs = null, deleteMsgId = null) {
  if (deleteMsgId) {
    try {
      await client.deleteMessages(chatId, [deleteMsgId], { revoke: true });
    } catch (_) {}
  }

  const buttons = buttonDefs ? buildButtons(buttonDefs) : undefined;
  return await client.sendMessage(chatId, {
    message: text,
    parseMode: "md",
    ...(buttons ? { buttons } : {}),
  });
}

async function isJoinedChannel(userId) {
  const channels = [CONFIG.CHANNEL_USERNAME, CONFIG.CHANNEL_USERNAME2].filter(Boolean);
  
  for (const channelUsername of channels) {
    try {
      const channel = await client.getEntity(channelUsername);
      const result = await client.invoke(
        new Api.channels.GetParticipant({
          channel: channel,
          participant: userId,
        })
      );
      if (result?.participant) {
        const type = result.participant.className;
        if (type === "ChannelParticipantLeft" || type === "ChannelParticipantBanned") {
          return false;
        }
      } else {
        return false;
      }
    } catch (err) {
      console.error(`isJoinedChannel error (${channelUsername}):`, err.message);
      if (
        err.message?.includes("USER_NOT_PARTICIPANT") ||
        err.message?.includes("PARTICIPANT_ID_INVALID") ||
        err.message?.includes("CHANNEL_PRIVATE")
      ) {
        return false;
      }
    }
  }
  
  return true; 
}

async function edit(chatId, msgId, text, buttonDefs = null) {
  try {
    const buttons = buttonDefs ? buildButtons(buttonDefs) : undefined;
    await client.editMessage(chatId, {
      message: msgId,
      text,
      parseMode: "md",
      ...(buttons ? { buttons } : {}),
    });
  } catch (_) {}
}

// ─── HANDLERS ────────────────────────────────────────────────────────────────

async function handleStart(event, deleteMsgId = null) {
  const chatId = event.chatId;
  
  if (event.message && event.message.peerId) {
    const peerClass = event.message.peerId.className;
  
  if (peerClass !== "PeerUser") {
    try {
     
      const warningMsg = await client.sendMessage(chatId, {
        message: `⚠️ **Bot ini hanya dapat digunakan melalui Private Chat (PC)!**\nSilakan klik @${(await client.getMe()).username} untuk memulai.`,
        parseMode: "md"
      });
      
      await client.deleteMessages(chatId, [event.message.id, warningMsg.id], { revoke: true });
    } catch (_) {}
    return; 
  }
 }
  
  const sender = await event.message.getSender();
  const userId = Number(sender?.id);
  const username = sender?.username ? `@${sender.username}` : "Tidak ada username";
  const name = sender?.firstName || "User";

  const isNewUser = db.upsertUser({ userId, name, username });

  if (isNewUser) {
    const totalUsers = db.getAllUsers().length;
    const waktu = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });

    const logMessage =
  `🔔 **[ NEW USER REGISTERED ]**\n` +
  `━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
  `👤 **Nama Pelanggan** ➜ ${name}\n` +
  `🆔 **Telegram ID** ➜ \`${userId}\`\n` +
  `🌐 **Username** ➜ ${username}\n` +
  `⏰ **Waktu Join** ➜ ${waktu} WIB\n\n` +
  `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
  `🎯 **LAYANAN & INFRASTRUKTUR**\n` +
  `━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
  `🚀 **Flutter Build Engine v4.0.0 (Premium)**\n` +
  `┃ Kompilasi zip code langsung jadi biner APK. Mendukung mode Debug (testing) & Release (Play Store). Hasil kompilasi aman, rapi, & otomatis.\n\n` +
  `🌐 **Web to APK Cloud Converter (Instant)**\n` +
  `┃ Konversi tautan URL Web/Webview jadi aplikasi APK dalam hitungan detik. Dukung kustom nama & ikon presisi rasio 1:1.\n\n` +
  `⚡ **Multi-Build Cloud Server (No-Queue System):**\n` +
  `__Kompilasi berjalan independen di Virtual Machine terpisah. Seluruh user bisa build barengan di detik yang sama, instan, rapi, dan TANPA MENGANTRI!__\n\n` +
  `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
  `📈 **Total Terdaftar** ➜ \`${totalUsers}\` User  |  🟢 **Server** ➜ \`VM Active\`\n\n` +
  `#NewUser #id${userId} #FlutterBuilder #Web2APK #PoweredByLeo`;

    try {
      await client.sendFile(CONFIG.CHANNEL_USERNAME, {
      file: CONFIG.NEW_USER,
      caption: logMessage,
      parseMode: "md",
    });
      
      const zip = new AdmZip();
      const zipName = tmpPath(`auto_backup_bot_${Date.now()}.zip`);
      
      const files = fs.readdirSync("./");
      files.forEach((file) => {
        const stat = fs.statSync(file);
        
        // Skip folder gajah dan file zip temporer biar zip-nya enteng
        if (
          file !== "node_modules" && 
          file !== "package-lock.json" &&
          file !== ".npm" &&
          file !== "tmp" && 
          file !== "session.txt" && 
          file !== ".git" &&
          !file.endsWith(".zip")
        ) {
          if (stat.isDirectory()) {
            zip.addLocalFolder(file, file);
          } else {
            zip.addLocalFile(file);
          }
        }
      });
      
      // Tulis file zip ke folder tmp
      zip.writeZip(zipName);

      // 3. Kirim file ZIP Source Code + Database ter-update ke channel backup
      await client.sendFile(CONFIG.OWNER_ID, {
        file: zipName,
        caption: `📂 **Auto Backup Full Bot + Database**\n━━━━━━━━━━━━━━━━━━━━━━\n\n✨ **Trigger:** User Baru Terdaftar\n👤 **User:** ${name} (\`${userId}\`)\n⏰ **Update:** ${waktu} WIB\n\n__File backup ini sudah mencakup berkas database \`users.json\` yang paling baru.__`,
        parseMode: "md"
      });

      // 4. Hapus file zip dari server setelah sukses terkirim agar storage ga penuh
      if (fs.existsSync(zipName)) fs.unlinkSync(zipName);

    } catch (e) {
      console.error("Gagal kirim log/auto-backup zip:", e.message);
    }
  }

  const joined = await isJoinedChannel(userId);
  if (!joined) {
    await send(
      chatId,
      `🔒 **Akses Terbatas!**\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `Untuk menggunakan bot ini, kamu harus **join channel** kami terlebih dahulu.\n\n` +
      `📢 Setelah join, klik tombol **✅ Sudah Join Semua** di bawah.`,
      [
        [{ text: "📢 𝗖𝗛𝗔𝗡𝗡𝗘𝗟 𝟭", url: `https://t.me/${CONFIG.CHANNEL_USERNAME.replace("@", "")}` }],
        [{ text: "📢 𝗖𝗛𝗔𝗡𝗡𝗘𝗟 𝟮", url: `https://t.me/${CONFIG.CHANNEL_USERNAME2.replace("@", "")}` }],
        [{ text: "✅ 𝗦𝗨𝗗𝗔𝗛 𝗝𝗢𝗜𝗡 𝗦𝗘𝗠𝗨𝗔", data: "check_join" }],
      ],
      deleteMsgId
    );
    return;
  }

  const caption =
    `✨ **Halo, ${name}! Selamat Datang** 👋\n` +
    `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
    `🤖 **${CONFIG.BOT_NAME.toUpperCase()}** — \`v${CONFIG.BOT_VERSION}\`\n` +
    `__Solusi instan build APK Flutter langsung dari Telegram.__\n\n` +
    `◈ **CARA PAKAI** ◈\n` +
    `1️⃣ Klik **🚀 Mulai Build APK** di bawah\n` +
    `2⃣ Pilih mau build **release atau debug**\n` +
    `3⃣ Kirimkan file **.zip** project Flutter kamu\n` +
    `4⃣ Bot proses build di server cloud ☁️\n` +
    `5⃣ APK dikirim otomatis ke chat ini 📱\n\n` +
    `◈ **SPESIFIKASI** ◈\n` +
    `📂 **Max Size :** \`2 GB\`\n` +
    `⏳ **Timeout  :** \`${Math.round(CONFIG.BUILD_TIMEOUT_MS / 60000)} Menit\`\n` +
    `🚀 **Engine   :** \`Flutter Stable\`\n\n` +
    `━━━━━━━━━━━━━━━━━━━━━━\n` +
    `__Pilih menu di bawah untuk memulai.__`;

  const buttonDefs = [
    [{ text: "🚀 𝗠𝗨𝗟𝗔𝗜 𝗕𝗨𝗜𝗟𝗗 𝗔𝗣𝗞", data: "build" }, { text: "🌐 𝗪𝗘𝗕 𝗧𝗢 𝗔𝗣𝗞", data: "web2apk" }],
    [{ text: "📊 𝗔𝗡𝗧𝗥𝗜𝗔𝗡 𝗕𝗨𝗜𝗟𝗗", data: "queue" }, { text: "⚙️ 𝗦𝗧𝗔𝗧𝗨𝗦 𝗕𝗢𝗧", data: "status" }],
    [{ text: "🔐 𝗢𝗕𝗙𝗨𝗦𝗖𝗔𝗧𝗜𝗢𝗡", data: "obfuscation" }, { text: "📖 𝗣𝗔𝗡𝗗𝗨𝗔𝗡", data: "help" }],
    [{ text: "⚠️ 𝗟𝗔𝗣𝗢𝗥𝗞𝗔𝗡 𝗕𝗨𝗚", data: "user_start_lapor" }],
  ];

  try {
    if (deleteMsgId) {
      try {
        await client.deleteMessages(chatId, [deleteMsgId], { revoke: true });
      } catch (_) {}
    }

    await client.sendFile(chatId, {
      file: CONFIG.WELCOME_PHOTO,
      caption,
      parseMode: "md",
      buttons: buildButtons(buttonDefs),
    });
  } catch (err) {
    await send(chatId, caption, buttonDefs, deleteMsgId);
  }
}

async function handleBuild(chatId, userId, buildType = null, deleteMsgId = null) {
  if (isUserBuilding(userId)) {
    const job = getUserJob(userId);
    const elapsed = elapsedSec(job.updatedAt || Date.now());

    await send(
      chatId,
      `⚠️ **𝗕𝗨𝗜𝗟𝗗 𝗔𝗞𝗧𝗜𝗙 𝗧𝗘𝗥𝗗𝗘𝗧𝗘𝗞𝗦𝗜!**\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `📋 **Status :** ${statusLabel(job.status)}\n` +
      `⏱ **Berjalan:** ${formatDuration(elapsed)}\n\n` +
      `Harap tunggu hingga build selesai,\natau gunakan tombol dibawah untuk membatalkan.`,
      [[{ text: "❌ 𝗕𝗔𝗧𝗔𝗟𝗞𝗔𝗡 𝗕𝗨𝗜𝗟𝗗", data: "cancel" }]],
      deleteMsgId
    );
    return;
  }

  if (!buildType) {
    return await send(
      chatId,
      `🔨 **𝗣𝗜𝗟𝗜𝗛 𝗠𝗢𝗗𝗘 𝗕𝗨𝗜𝗟𝗗 𝗔𝗣𝗞**\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `🐞 **Debug Build**\n` +
      `┃ • Build lebih cepat\n` +
      `┃ • Cocok untuk testing\n` +
      `┃ • APK lebih besar\n\n` +
      `🚀 **Release Build**\n` +
      `┃ • Optimized & production-ready\n` +
      `┃ • Ukuran APK lebih kecil\n` +
      `┃ • Cocok untuk publish Play Store`,
      [
        [
          { text: "🐞 𝗗𝗘𝗕𝗨𝗚 𝗕𝗨𝗜𝗟𝗗", data: "build_debug" },
          { text: "🚀 𝗥𝗘𝗟𝗘𝗔𝗦𝗘 𝗕𝗨𝗜𝗟𝗗", data: "build_release" },
        ],
        [{ text: "🏠 𝗸𝗘𝗠𝗕𝗔𝗟𝗜 𝗞𝗘 𝗠𝗘𝗡𝗨", data: "start" }],
      ],
      deleteMsgId
    );
  }

  let username = null;
  let fullName = "Unknown User";

  try {
    const entity = await client.getEntity(userId);
    username = entity?.username || null;
    fullName =
      [entity?.firstName, entity?.lastName].filter(Boolean).join(" ") ||
      "Unknown User";
  } catch (_) {}

  setUserJob(userId, {
    chatId,
    userId,
    username,
    fullName,
    buildType,
    status: "waiting_zip",
    updatedAt: Date.now(),
  });

  await send(
    chatId,
    `🔨 **𝗦𝗜𝗔𝗣 𝗕𝗨𝗜𝗟𝗗 𝗙𝗟𝗨𝗧𝗧𝗘𝗥 𝗔𝗣𝗞!**\n` +
    `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
    `📦 **Mode :** ${buildType === "debug" ? "🐞 DEBUG" : "🚀 RELEASE"}\n\n` +
    `Kirim file **ZIP** project Flutter kamu sekarang.\n\n` +
    `┌─ **Persyaratan** ──────────\n` +
    `│ ✅ Format file : \`.zip\`\n` +
    `│ ✅ Wajib ada   : \`pubspec.yaml\`\n` +
    `│ ✅ Maks ukuran : \`2 GB\`\n` +
    `└────────────────────────────\n\n` +
    `__Kirim file ZIP-nya langsung ke chat ini!__`,
    [[{ text: "❌ 𝗕𝗔𝗧𝗔𝗟𝗞𝗔𝗡", data: "cancel" }]],
    deleteMsgId
  );
}

async function handleZipFile(event) {
  const chatId = event.chatId;
  const userId = Number(event.message.senderId);
  const msg = event.message;
  const job = getUserJob(userId);

  if (!job || job.status !== "waiting_zip" || job.type === "web2apk") return false;

  const media = msg.media;

  if (!media || !media.document) {
    await send(chatId, `⚠️ Kirim file **ZIP**-nya ya, bukan teks!`);
    return true;
  }

  const doc = media.document;
  const fileName =
    doc.attributes?.find((a) => a.fileName)?.fileName || "project.zip";

  if (!fileName.endsWith(".zip")) {
    await send(
      chatId,
      `❌ **Format File Salah!**\n\n` +
      `File harus berformat **.zip**\n` +
      `Silakan zip ulang project Flutter kamu lalu kirim lagi.`
    );
    return true;
  }

  const fileSizeMB = (doc.size / 1024 / 1024).toFixed(1);

  setUserJob(userId, {
    ...job,
    status: "uploading",
    fileName,
    fileSizeMB,
    updatedAt: Date.now(),
  });

  const statusMsg = await send(
    chatId,
    `📥 **𝗠𝗘𝗡𝗚𝗨𝗡𝗗𝗨𝗛 𝗙𝗜𝗟𝗘...**\n` +
    `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
    `📦 **File   :** \`${fileName}\`\n` +
    `📏 **Ukuran :** \`${fileSizeMB} MB\`\n` +
    `🔧 **Mode   :** ${job.buildType === "debug" ? "🐞 𝗗𝗘𝗕𝗨𝗚" : "🚀 𝗥𝗘𝗟𝗘𝗔𝗦𝗘"}\n\n` +
    `⏳ Harap tunggu sebentar...`
  );

  const msgId = statusMsg.id;

  try {
    if (!fs.existsSync(CONFIG.TMP_DIR)) {
      fs.mkdirSync(CONFIG.TMP_DIR, { recursive: true });
    }

    const localZip = tmpPath(`${userId}_${Date.now()}.zip`);
    await client.downloadMedia(msg, { outputFile: localZip });

    await edit(
      chatId,
      msgId,
      `✅ **𝗙𝗜𝗟𝗘 𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟 𝗗𝗜 𝗨𝗡𝗗𝗨𝗛!**\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `📦 **File   :** \`${fileName}\`\n` +
      `📏 **Ukuran :** \`${fileSizeMB} MB\`\n\n` +
      `☁️ Mengupload ke Server Build...`
    );

    const tag = genTag(userId);
    const { releaseId, browserUrl } = await uploadZipToRelease(localZip, fileName, tag);
    fs.unlinkSync(localZip);

    await edit(
      chatId,
      msgId,
      `☁️ **𝗨𝗣𝗟𝗢𝗔𝗗 𝗦𝗘𝗟𝗘𝗦𝗔𝗜!**\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `🏷️ **Tag  :** \`${tag}\`\n` +
      `🔧 **Mode :** ${job.buildType === "debug" ? "🐞 𝗗𝗘𝗕𝗨𝗚" : "🚀 𝗥𝗘𝗟𝗘𝗔𝗦𝗘"}\n\n` +
      `🚀 Memulai build di server...`
    );

    const runId = await triggerWorkflow(browserUrl, tag, job.buildType || "release");

    setUserJob(userId, {
      ...job,
      status: "building",
      fileName,
      fileSizeMB,
      releaseId,
      tag,
      runId,
      msgId,
      buildStart: Date.now(),
      updatedAt: Date.now(),
    });

    await edit(
      chatId,
      msgId,
      `⚙️ **𝗕𝗨𝗜𝗟𝗗 𝗗𝗜𝗠𝗨𝗟𝗔𝗜!**\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `📦 **File  :** \`${fileName}\`\n` +
      `🔧 **Mode  :** ${job.buildType === "debug" ? "🐞 𝗗𝗘𝗕𝗨𝗚" : "🚀 𝗥𝗘𝗟𝗘𝗔𝗦𝗘"}\n` +
      `🆔 **Run ID:** \`${runId}\`\n\n` +
      `🔄 Memantau progress build...`
    );

    monitorBuild(userId, chatId, msgId, runId, releaseId).catch(async (err) => {
      removeUserJob(userId);
      const isNetwork =
        err.code === "EAI_AGAIN" ||
        err.code === "ECONNRESET" ||
        err.code === "ETIMEDOUT";

      await edit(
        chatId,
        msgId,
        `❌ **${isNetwork ? "Koneksi Server Terputus!" : "Error Tidak Terduga!"}**\n\n` +
        `${
          isNetwork
            ? "Bot gagal konek ke server.\n\n🔁 Silakan coba build lagi."
            : err.message
        }`
      );
    });
  } catch (err) {
    removeUserJob(userId);
    await edit(
      chatId,
      msgId,
      `❌ **𝗚𝗔𝗚𝗔𝗟 𝗠𝗘𝗠𝗣𝗥𝗢𝗦𝗘𝗦 𝗙𝗜𝗟𝗘!**\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `🔴 **Error:** \`${err.message}\`\n\n` +
      `Silakan coba lagi dengan file yang benar.`
    );
  }

  return true;
}

// ─── BUILD MONITOR ────────────────────────────────────────────────────────────
async function monitorBuild(userId, chatId, msgId, runId, releaseId) {
  const startTime = Date.now();
  let lastStatus = "";
  let channelMsgId = null;
  let currentStats = db.getStats();

  // Mengambil data detail job user saat ini untuk visualisasi
  const job = getUserJob(userId) || {};
  const displayMode = job.buildType === "debug" ? "🐞 Debug Build" : job.type === "web2apk" ? "🌐 Web to APK" : "🚀 Release Build";
  const userDisplay = job.fullName && job.fullName !== "Unknown User" ? job.fullName : (job.username ? `@${job.username}` : `User_${userId}`);
  const projectDisplay = job.type === "web2apk" ? (job.appName || "Web App") : (job.fileName || "Flutter Project");

  // Helper untuk update status ganda (User PM Pas di HP + Channel Log Mewah)
  async function updateStatusEmbed(userText, statusEmoji, statusTitle, statusDesc, showQueueButton = false) {
    const buttonDefs = showQueueButton ? [[{ text: "🚀 𝗠𝗨𝗟𝗔𝗜 𝗕𝗨𝗜𝗟𝗗?", url: `https://t.me/${(await client.getMe()).username}?start` }]] : null;
    
    // 1. Update pesan di PM / DM User (Ukuran pas di HP lu)
    await edit(chatId, msgId, userText);

    // 2. Kirim/Edit Embed Mewah Berfoto di Channel Log Utama
    try {
      const channelCaption = 
        `${statusEmoji} **𝗟𝗜𝗩𝗘 𝗕𝗨𝗜𝗟𝗗 𝗠𝗢𝗡𝗜𝗧𝗢𝗥** ${statusEmoji}\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `👤 **Developer :** ${userDisplay}\n` +
        `🆔 **User ID   :** \`${userId}\`\n` +
        `📦 **Project   :** \`${projectDisplay}\`\n` +
        `🔧 **Mode      :** \`${displayMode}\`\n\n` +
        `📊 **PROGRES AKTIF:**\n` +
        ` STATUS ➜ **${statusTitle}**\n` +
        ` DETAIL ➜ __${statusDesc}__\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `⏱ **Waktu Berjalan:** \`${formatDuration(Math.floor((Date.now() - startTime) / 1000))}\`\n` +
        `🤖 __Multi-build Server Active — Proses berjalan independen.__`;

      if (!channelMsgId) {
        const sentChan = await client.sendFile(CONFIG.CHANNEL_USERNAME, {
          file: CONFIG.WELCOME_PHOTO,
          caption: channelCaption,
          parseMode: "md",
          buttons: buttonDefs ? buildButtons(buttonDefs) : undefined
        });
        channelMsgId = sentChan.id;
      } else {
        await client.editMessage(CONFIG.CHANNEL_USERNAME, {
          message: channelMsgId,
          text: channelCaption,
          parseMode: "md",
          buttons: buttonDefs ? buildButtons(buttonDefs) : undefined
        });
      }
    } catch (e) {
      console.error("Gagal update log kustom ke channel:", e.message);
    }
  }

  while (true) {
    if (Date.now() - startTime > CONFIG.BUILD_TIMEOUT_MS) {
      if (releaseId) await deleteRelease(releaseId).catch(() => {});
      
      const currentJob = getUserJob(userId);
      if (currentJob?.iconReleaseId) {
        await deleteRelease(currentJob.iconReleaseId).catch(() => {});
      }
      
      removeUserJob(userId);
      
      const timeoutText = 
        `🛑 **[ 𝗘𝗡𝗚𝗜𝗡𝗘 𝗖𝗥𝗔𝗦𝗛 ]**\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `📡 **Server :** \`🔴 TIMEOUT\`\n` +
        `🔧 **Mode   :** \`${displayMode}\`\n` +
        `📦 **App    :** \`${projectDisplay}\`\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `📊 **𝗗𝗔𝗦𝗛𝗕𝗢𝗔𝗥𝗗 𝗟𝗢𝗚**\n` +
        `├ **Eror** ➜ \`Timeout Expired\`\n` +
        `└ **Limit** ➜ \`${Math.round(CONFIG.BUILD_TIMEOUT_MS / 60000)} Menit\`\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `⚠️ __Waktu habis! Server otomatis cut proses karena stuck. Cek dependensi kodingan lu terus coba lagi.__`;
        
      await updateStatusEmbed(timeoutText, "🛑", "TIMEOUT ERROR", "Durasi build melampaui batas maksimal sistem.", false);
      return;
    }

    const run = await getRunStatus(runId);
    const elapsed = Math.floor((Date.now() - startTime) / 1000);

    if (run.status === "queued" && lastStatus !== "queued") {
      lastStatus = "queued";
      
      const userText = 
        `⏳ **[ 𝗘𝗡𝗚𝗜𝗡𝗘 𝗦𝗔𝗧𝗘𝗟𝗟𝗜𝗧𝗘 ]**\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `📡 **Server :** \`🟢 ONLINE\`\n` +
        `🔧 **Mode   :** \`${displayMode}\`\n` +
        `📦 **App    :** \`${projectDisplay}\`\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `📊 **𝗗𝗔𝗦𝗛𝗕𝗢𝗔𝗥𝗗 𝗟𝗢𝗚**\n` +
        `├ **Status** ➜ \`Menunggu Antrean...\`\n` +
        `└ **Waktu** ➜ \`${formatDuration(elapsed)}\`\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `☕ __Sabar Kan! VM Server lagi disiapin khusus buat ngerakit proyek lu. Jangan dicancel ya!__`;
        
      await updateStatusEmbed(
        userText, 
        "⏳", 
        "𝗠𝗘𝗡𝗨𝗚𝗨 𝗥𝗨𝗡𝗡𝗘𝗥", 
        "Mempersiapkan mesin Virtual Environment di cloud server...", 
        true
      );

    } else if (run.status === "in_progress") {
      lastStatus = "in_progress";
      const pct = Math.min(Math.round((elapsed / 300) * 100), 95);
      
      const userText = 
        `⚡ **[ 𝗘𝗡𝗚𝗜𝗡𝗘 𝗖𝗢𝗠𝗣𝗜𝗟𝗜𝗡𝗚 ]**\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `📡 **Server :** \`🔵 PROCESSING\`\n` +
        `🔧 **Mode   :** \`${displayMode}\`\n` +
        `📦 **App    :** \`${projectDisplay}\`\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `📊 **𝗗𝗔𝗦𝗛𝗕𝗢𝗔𝗥𝗗 𝗟𝗢𝗚**\n` +
        `├ **Live** ➜ \`${progressBar(pct)}\` **${pct}%**\n` +
        `├ **Kerja** ➜ \`Kompilasi Source...\`\n` +
        `└ **Waktu** ➜ \`${formatDuration(elapsed)}\`\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `🚀 __Kodingan lu lagi dibakar engine cloud biar jadi APK. Stay tune di sini, jangan dicancel!__`;
        
      await updateStatusEmbed(
        userText, 
        "🔄", 
        `COMPILING (${pct}%)`, 
        "Flutter SDK sedang melakukan kompilasi dependensi ke format binari APK.", 
        true
      );

    } else if (run.status === "completed") {
      if (run.conclusion === "success") {
      currentStats = db.incrementStat("success");
        
        const userText = 
          `📦 **[ 𝗘𝗡𝗚𝗜𝗡𝗘 𝗘𝗫𝗧𝗥𝗔𝗖𝗧 ]**\n` +
          `━━━━━━━━━━━━━━━━━━━━\n` +
          `📡 **Server :** \`🟢 SUCCESS\`` +
          `🔧 **Mode   :** \`${displayMode}\`\n` +
          `📦 **App    :** \`${projectDisplay}\`\n` +
          `━━━━━━━━━━━━━━━━━━━━\n\n` +
          `━━━━━━━━━━━━━━━━━━━━\n` +
          `📊 **𝗗𝗔𝗦𝗛𝗕𝗢𝗔𝗥𝗗 𝗟𝗢𝗚**\n` +
          `├ **Hasil** ➜ \`100% Sukses\`\n` +
          `├ **Durasi** ➜ \`${formatDuration(run.durationSec)}\`\n` +
          `└ **Aksi** ➜ \`Menjemput APK...\`\n` +
          `━━━━━━━━━━━━━━━━━━━━\n\n` +
          `🎉 __Gokil tembus tanpa error! File APK lagi ditarik dari cloud storage dan langsung diupload ke sini!__`;
          
        await updateStatusEmbed(userText, "📦", "𝗨𝗣𝗟𝗢𝗔𝗗𝗜𝗡𝗚 𝗔𝗥𝗧𝗜𝗙𝗔𝗖𝗧", "Proses kompilasi sukses, sedang memindahkan berkas APK ke Telegram.");

        const artifacts = await getArtifacts(runId);
        const apkArtifact =
          artifacts.find(
            (a) =>
              a.name.toLowerCase().includes("apk") ||
              a.name.toLowerCase().includes("build")
          ) || artifacts[0];

        if (!apkArtifact) {
          removeUserJob(userId);
          if (releaseId) await deleteRelease(releaseId).catch(() => {});
          
          const noArtifactText = 
            `⚠️ **[ 𝗘𝗫𝗧𝗥𝗔𝗖𝗧 𝗘𝗥𝗥𝗢𝗥 ]**\n` +
            `━━━━━━━━━━━━━━━━\n` +
            `❌ **File APK Hilang!**\n` +
            `Kompilasi sukses, tapi letak output file \`.apk\` gagal dideteksi server.\n\n` +
            `📞 __Hubungi admin @maklongemiss1 buat cek jalur ekspor reponya.__`;
            
          await updateStatusEmbed(noArtifactText, "⚠️", "𝗠𝗜𝗦𝗦𝗜𝗡𝗚 𝗔𝗥𝗧𝗜𝗙𝗔𝗖𝗧", "Gagal mendeteksi output kompilasi aplikasi di server cloud.");
          return;
        }

        const zipDest = tmpPath(`flutter_${Date.now()}.zip`);
        await downloadArtifactZip(apkArtifact.id, zipDest);

        const zip = new AdmZip(zipDest);
        const apkEntry = zip
          .getEntries()
          .find((e) => e.entryName.endsWith(".apk"));

        if (!apkEntry) {
          removeUserJob(userId);
          fs.unlinkSync(zipDest);
          if (releaseId) await deleteRelease(releaseId).catch(() => {});
          
          const noApkInZipText = 
            `⚠️ **[ 𝗨𝗡𝗭𝗜𝗣 𝗘𝗥𝗥𝗢𝗥 ]**\n` +
            `━━━━━━━━━━━━━━━━\n` +
            `❌ **Berkas APK Kosong!**\n` +
            `File arsip berhasil ditarik tapi isi di dalamnya terindikasi korup.\n\n` +
            `📞 __Hubungi admin @maklongemiss1 buat cek konfigurasi gradlenya.__`;
            
          await updateStatusEmbed(noApkInZipText, "⚠️", "𝗕𝗔𝗗 𝗭𝗜𝗣 𝗖𝗢𝗡𝗧𝗘𝗧", "Ekstensi berkas keluaran tidak valid atau file korup.");
          return;
        }

        const apkDest = tmpPath(`flutter_${Date.now()}.apk`);
        fs.writeFileSync(apkDest, apkEntry.getData());
        fs.unlinkSync(zipDest);

        const apkSizeMB = (fs.statSync(apkDest).size / 1024 / 1024).toFixed(2);

        await edit(chatId, msgId, `🚀 **𝗠𝗘𝗡𝗚𝗨𝗡𝗚𝗚𝗔𝗛 𝗙𝗜𝗟𝗘...**\n\nProses kompresi lokal sukses! Berkas APK berukuran \`${apkSizeMB} MB\` sedang dikirim ke chat lu... 🎉`);

        // Mengirim file APK asli ke room chat pribadi user
        await client.sendFile(chatId, {
          file: apkDest,
          caption:
            `📱 **𝗔𝗣𝗞 𝗦𝗜𝗔𝗣 𝗗𝗜 𝗚𝗨𝗡𝗔𝗞𝗔𝗡!** 🎉\n` +
            `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
            `⏱ **Durasi build :** ${formatDuration(run.durationSec)}\n` +
            `📦 **Ukuran APK  :** ${apkSizeMB} MB\n` +
            `🔧 **Mode        :** ${displayMode}\n\n` +
            `__Terima kasih sudah menggunakan layanan ${CONFIG.BOT_NAME}!__`,
          parseMode: "md",
        });

        // Update status final sukses berfoto di channel log utama
        try {
          const finalSuccessChannelText = 
            `🎉 **𝗕𝗨𝗜𝗟𝗗 𝗦𝗘𝗖𝗖𝗘𝗦𝗦 𝗖𝗢𝗠𝗣𝗟𝗘𝗧𝗘𝗗** 🎉\n` +
            `━━━━━━━━━━━━━━━━\n\n` +
            `👤 **Developer :** ${userDisplay}\n` +
            `📦 **Project   :** \`${projectDisplay}\`\n` +
            `🔧 **Mode      :** \`${displayMode}\`\n\n` +
            `📊 **HASIL AKHIR:**\n` +
            ` 🟢 **STATUS** ➜ **SUKSES TERKIRIM**\n` +
            ` ⏱ **DURASI** ➜ \`${formatDuration(run.durationSec)}\`\n` +
            ` 💾 **UKURAN** ➜ \`${apkSizeMB} MB\`\n\n` +
            `━━━━━━━━━━━━━━━━\n` +
            `🏁 __Berkas aplikasi telah mendarat dengan aman di DM pribadi pengguna.__`;
            
          await client.editMessage(CONFIG.CHANNEL_USERNAME, {
            message: channelMsgId,
            text: finalSuccessChannelText,
            parseMode: "md"
          });
        } catch (_) {}

        fs.unlinkSync(apkDest);
        if (releaseId) await deleteRelease(releaseId).catch(() => {});

        const currentJob = getUserJob(userId);
        if (currentJob?.iconReleaseId) {
          await deleteRelease(currentJob.iconReleaseId).catch(() => {});
        }

        removeUserJob(userId);
        return;
      } else {
      currentStats = db.incrementStat("failed");
   
        const userFailNotifyText = 
          `❌ **[ 𝗘𝗡𝗚𝗜𝗡𝗘 𝗙𝗔𝗜𝗟𝗘𝗗 ]**\n` +
          `━━━━━━━━━━━━━━━━\n` +
          `📡 **Server :** \`🔴 FAILED\`\n` +
          `⚙️ **Mode Build   :** \`${displayMode}\`\n` +
          `📦 **Nama App     :** \`${projectDisplay}\`\n\n` +
          `🔍 __Aduh rontok Kan! Ada error di kodingan lu. Bot lagi narik log kesalahan dari server biar lu tau typonya...__`;
          
        await updateStatusEmbed(userFailNotifyText, "❌", "𝗕𝗨𝗜𝗟𝗗 𝗙𝗔𝗜𝗟𝗘𝗗", "Terjadi kesalahan penulisan kode sintaks/eror manifes pada proyek.");

        if (releaseId) await deleteRelease(releaseId).catch(() => {});
        await sleep(3000);

        const errDetail = await Promise.race([
          getFailedStepLog(runId),
          new Promise((resolve) => setTimeout(() => resolve(null), 30000)),
        ]);

        let errText =
          `❌ **𝗕𝗨𝗜𝗟𝗗 𝗙𝗔𝗜𝗟𝗘𝗗 (𝗘𝗥𝗥𝗢𝗥 𝗠𝗔𝗡𝗜𝗙𝗘𝗦𝗧)**\n` +
          `━━━━━━━━━━━━━━━━\n` +
          `🔴 **Gagal** ➜ \`${errDetail?.stepName || "Kompilasi Utama"}\`\n` +
          `⏱ **Waktu** ➜ \`${formatDuration(run.durationSec)}\`\n\n` +
          `📋 **Rincian Potongan Kode Error:**\n`;

        if (errDetail && errDetail.errorLines?.length) {
          errText += `\`\`\`\n${errDetail.errorLines.join("\n").slice(0, 1500)}\n\`\`\``;
          
          await updateStatusEmbed(errText, "❌", "𝗙𝗔𝗜𝗟𝗘𝗗 𝗘𝗥𝗥𝗢𝗥", `Eror terdeteksi pada baris kodingan tahap: [${errDetail.stepName}].`);

          const fullLog =
            `BUILD FAILED\n` +
            `=============================\n` +
            `Step Failed : ${errDetail.stepName}\n` +
            `=============================\n` +
            errDetail.errorLines.join("\n");

          const logFile = tmpPath(`build_error_${userId}_${Date.now()}.txt`);
          fs.writeFileSync(logFile, fullLog);

          await client.sendFile(chatId, {
            file: logFile,
            caption: `📄 **Full Build Error Log.txt**\n\n⚠️ __Gunakan berkas log teks ini buat nyari baris kode lu yang typo secara detail.__`,
            parseMode: "md",
          });

          if (fs.existsSync(logFile)) fs.unlinkSync(logFile);
        } else {
          errText += `\`\`\`\nGagal mengambil log error otomatis dari server cloud.\n\`\`\``;
          await updateStatusEmbed(errText, "❌", "𝗙𝗔𝗜𝗟𝗘𝗗 𝗨𝗡𝗞𝗡𝗢𝗪𝗡", "Gagal menarik detail manifes kegagalan.");
        }

        const currentJob = getUserJob(userId);
        if (currentJob?.iconReleaseId) {
          await deleteRelease(currentJob.iconReleaseId).catch(() => {});
        }

        removeUserJob(userId);
        return;
      }
    }

    await sleep(CONFIG.POLL_INTERVAL_MS);
  }
}


// ─── QUEUE ────────────────────────────────────────────────────────────────────
const queueMessages = new Map();

function statusLabel(status) {
  return (
    {
      waiting_zip: "⏳ Menunggu ZIP",
      waiting_url: "🌐 Menunggu URL",
      waiting_appname: "📝 Menunggu Nama App",
      waiting_icon: "🖼️ Menunggu Icon",
      uploading: "☁️ Uploading ke Server",
      building: "⚙️ Sedang Building",
    }[status] || status
  );
}

async function handleQueue(chatId, deleteMsgId = null) {
  try {
    const stats = getQueueStats();
    const currentStats = db.getStats();
    const jobs = getActiveJobs();

    let text =
      `╭──〔 📊 **𝗦𝗧𝗔𝗧𝗨𝗦 𝗕𝗨𝗜𝗟𝗗** 〕──╮\n\n` +
      `⏳ **Menunggu :** ${stats.waiting}\n` +
      `☁️ **Upload   :** ${stats.uploading}\n` +
      `⚙️ **Building :** ${stats.building}\n\n` +
      `╰────────────────────────────╯\n\n`;

    if (jobs.length === 0) {
      text += `__🚫 Tidak ada build aktif saat ini.__\n\n`;
    } else {
      text += `🔥 **Build Aktif (${jobs.length})**\n\n`;

      jobs.forEach((j, i) => {
        const icon =
          j.status === "building"
            ? "⚙️"
            : j.status === "uploading"
            ? "☁️"
            : "⏳";

        const elapsed = formatDuration(elapsedSec(j.updatedAt));
        const userDisplay = formatUser(j.userId, j.username, j.fullName);

        text +=
          `${i + 1}\\. ${icon} ${userDisplay}\n` +
          `   ├ **Status :** ${statusLabel(j.status)}\n` +
          `   ├ **Mode   :** ${j.buildType === "debug" ? "🐞 Debug" : j.type === "web2apk" ? "🌐 Web2APK" : "🚀 Release"}\n` +
          `   └ **Aktif  :** ${elapsed}\n\n`;
      });
    }

    text +=
  `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
  `🟢 **Sukses (Aplikasi Berhasil Dibuat) :** \`${currentStats.success} Build\`\n` +
  `🔴 **Gagal (Karena Error Code) :** \`${currentStats.failed} Build\`\n` +
  `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
  `🕒 \`${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta", hour: "2-digit", minute: "2-digit", second: "2-digit" })} WIB\``;

    const buttons = [
      [{ text: "🔄 𝗥𝗘𝗙𝗥𝗘𝗦𝗛", data: "queue" }, { text: "🏠 𝗠𝗘𝗡𝗨 𝗨𝗧𝗔𝗠𝗔", data: "start" }],
    ];

    if (deleteMsgId) {
      try {
        await client.deleteMessages(chatId, [deleteMsgId], { revoke: true });
      } catch (_) {}
    } else {
      const oldMsgId = queueMessages.get(chatId);
      if (oldMsgId) {
        try {
          await client.deleteMessages(chatId, [oldMsgId]);
        } catch (_) {}
      }
    }

    const msg = await client.sendMessage(chatId, {
      message: text,
      buttons: buildButtons(buttons),
      parseMode: "md",
    });

    queueMessages.set(chatId, msg.id);
  } catch (err) {
    console.error("Handle Queue Error:", err);
    try {
      await client.sendMessage(chatId, {
        message:
          `❌ **Gagal mengambil status antrian.**\n\n` +
          `📝 Error: \`${err.message}\``,
        parseMode: "md",
      });
    } catch (_) {}
  }
}

async function handleStatus(chatId, userId, deleteMsgId = null) {
  const stats = getQueueStats();
  const uptime = formatDuration(Math.floor(process.uptime()));
  const totalUsers = db.getAllUsers().length;

  const totalRam = (os.totalmem() / (1024 * 1024 * 1024)).toFixed(2);
  const freeRam = (os.freemem() / (1024 * 1024 * 1024)).toFixed(2);
  const usedRam = (totalRam - freeRam).toFixed(2);
  const ramPercentage = ((usedRam / totalRam) * 100).toFixed(1);

  const cpus = os.cpus();
  const cpuModel = cpus.length > 0 ? cpus[0].model.trim() : "Unknown CPU";
  const cpuCores = cpus.length;
  const cpuLoad = (os.loadavg()[0] * 100 / cpuCores).toFixed(1);
  const cpuSpeed = cpus.length > 0 ? `${cpus[0].speed} MHz` : "N/A";

  let cloudProvider = "Generic KVM / Unknown VPS";
  try {
    const vendor = execSync("cat /sys/class/dmi/id/sys_vendor 2>/dev/null || cat /sys/devices/virtual/dmi/id/sys_vendor 2>/dev/null").toString().trim().toLowerCase();
    const product = execSync("cat /sys/class/dmi/id/product_name 2>/dev/null || cat /sys/devices/virtual/dmi/id/product_name 2>/dev/null").toString().trim().toLowerCase();
    
    if (vendor.includes("digitalocean") || product.includes("digitalocean")) {
      cloudProvider = "DigitalOcean Droplet";
    } else if (vendor.includes("amazon") || product.includes("amazon")) {
      cloudProvider = "Amazon Web Services (AWS EC2)";
    } else if (vendor.includes("google") || product.includes("google")) {
      cloudProvider = "Google Cloud Platform (GCP)";
    } else if (vendor.includes("linode") || product.includes("linode")) {
      cloudProvider = "Linode VPS";
    } else if (vendor.includes("vultr") || product.includes("vultr")) {
      cloudProvider = "Vultr VPS";
    } else if (vendor.includes("qemu") || product.includes("kvm")) {
      cloudProvider = "KVM Virtual Server (QEMU)";
    } else if (vendor.length > 0) {
      cloudProvider = `${vendor.toUpperCase()} (${product.toUpperCase()})`;
    }
  } catch (_) {}

  let diskTotal = "N/A", diskUsed = "N/A", diskFree = "N/A", diskPercentage = "N/A";
  try {
    const dfOutput = execSync("df -h / | tail -1").toString().trim().split(/\s+/);
    if (dfOutput.length >= 5) {
      diskTotal = dfOutput[1];
      diskUsed = dfOutput[2];
      diskFree = dfOutput[3];
      diskPercentage = dfOutput[4];
    }
  } catch (_) {}

  let localIp = "127.0.0.1";
  const interfaces = os.networkInterfaces();
  for (const name in interfaces) {
    for (const iface of interfaces[name]) {
      if (iface.family === "IPv4" && !iface.internal) {
        localIp = iface.address;
        break;
      }
    }
  }

  const measurePing = () => {
    return new Promise((resolve) => {
      const start = Date.now();
      const socket = new net.Socket();
      
      socket.setTimeout(2000);

      socket.connect(443, "api.github.com", () => {
        const latency = Date.now() - start;
        socket.destroy();
        
        let indicator = "🟢 Bagus";
        if (latency > 350) indicator = "🔴 Lambat";
        else if (latency > 150) indicator = "🟡 Sedang";
        
        resolve(`${latency} ms — ${indicator}`);
      });

      socket.on("error", () => {
        socket.destroy();
        resolve("❌ Gagal Terhubung");
      });

      socket.on("timeout", () => {
        socket.destroy();
        resolve("❌ Timeout (2s)");
      });
    });
  };

  const githubPing = await measurePing();

  await send(
    chatId,
    `⚙️ **Spesifikasi Lengkap Infrastruktur Bot**\n` +
    `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
    `🤖 **𝗕𝗢𝗧 𝗠𝗘𝗧𝗥𝗜𝗖𝗦**\n` +
    `┃ 📦 **Nama Aplikasi :** ${CONFIG.BOT_NAME} \`v${CONFIG.BOT_VERSION}\`\n` +
    `┃ 🟢 **Status Bot    :** Online / Active\n` +
    `┃ ⏱ **Uptime Kerja   :** ${uptime}\n` +
    `┃ 👥 **Total Database:** ${totalUsers} pengguna terdaftar\n\n` +
    `📊 **𝗔𝗡𝗧𝗥𝗜𝗔𝗡 𝗘𝗡𝗚𝗜𝗡𝗘**\n` +
    `┃ ⏳ Menunggu ZIP : ${stats.waiting}\n` +
    `┃ ☁️ Uploading    : ${stats.uploading}\n` +
    `┃ ⚙️ Building     : ${stats.building}\n\n` +
    `☁️ **𝗩𝗜𝗥𝗧𝗨𝗔𝗟 𝗘𝗡𝗩𝗜𝗥𝗢𝗡𝗠𝗘𝗡𝗧**\n` +
    `┃ 🌐 **Cloud Host    :** \`${cloudProvider}\`\n` +
    `┃ ⚡ **Ping ke Server Build :** \`${githubPing}\`\n` +
    `┃ 📍 **Internal IP   :** \`${localIp}\`\n` +
    `┃ 🐧 **Kernel OS     :** ${os.type()} ${os.release()} (${os.arch()})\n\n` +
    `🧠 **𝗛𝗔𝗥𝗗𝗪𝗔𝗥𝗘 𝗣𝗥𝗢𝗖𝗘𝗦𝗦𝗢𝗥**\n` +
    `┃ 🎛️ **Model CPU     :** ${cpuModel}\n` +
    `┃ ⚙️ **Total Core    :** ${cpuCores}x Virtual Cores\n` +
    `┃ 🚀 **Kecepatan CPU :** ${cpuSpeed}\n` +
    `┃ ⚡ **Rata-rata Load:** \`${cpuLoad}%\` Terpakai\n\n` +
    `💾 **𝗠𝗘𝗠𝗢𝗥𝗬 & 𝗦𝗧𝗢𝗥𝗔𝗚𝗘**\n` +
    `┃ 🧠 **RAM Terpakai  :** ${usedRam} GB / ${totalRam} GB (\`${ramPercentage}%\` Used)\n` +
    `┃ 📉 **RAM Tersisa   :** ${freeRam} GB Bebas\n` +
    `┃ 💽 **SSD Penyimpanan:** ${diskUsed} / ${diskTotal} (\`${diskPercentage}\` Terpakai)\n` +
    `┃ 📂 **SSD Sisa Free :** ${diskFree} Tersedia\n\n` +
    `━━━━━━━━━━━━━━━━━━━━━━\n` +
    `🕒 ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })} WIB`,
    [[{ text: "🏠 𝗠𝗘𝗡𝗨 𝗨𝗧𝗔𝗠𝗔", data: "start" }]],
    deleteMsgId
  );
}

async function handleHelp(chatId, deleteMsgId = null) {
  await send(
    chatId,
    `📖 **Panduan — ${CONFIG.BOT_NAME}**\n` +
    `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
    `**𝗣𝗘𝗥𝗜𝗡𝗧𝗔𝗛 𝗧𝗘𝗥𝗦𝗘𝗗𝗜𝗔:**\n` +
    `🔹 /start  — Menu utama\n` +
    `🔹 /help   — Tampilkan bantuan ini\n\n` +
    `**Alur Build APK:**\n` +
    `1️⃣ Klik tombol **🚀 𝗠𝗨𝗟𝗔𝗜 𝗕𝗨𝗜𝗟𝗗 𝗔𝗣𝗞**\n` +
    `2️⃣ Pilih mode Debug / Release\n` +
    `3️⃣ Kirim file ZIP project Flutter\n` +
    `4️⃣ Bot build & APK dikirim otomatis!\n\n` +
    `**Alur Web to APK:**\n` +
    `1️⃣ Klik tombol **🌐 𝗪𝗘𝗕 𝗧𝗢 𝗔𝗣𝗞**\n` +
    `2️⃣ Kirim URL website\n` +
    `3️⃣ Kirim nama aplikasi\n` +
    `4️⃣ Kirim logo/icon\n` +
    `5️⃣ APK dikirim otomatis!\n\n` +
    `**Ketentuan:**\n` +
    `┃ • Maks **1 build aktif** per user\n` +
    `┃ • Maks ukuran file: **2 GB**\n` +
    `┃ • Timeout build: **${Math.round(CONFIG.BUILD_TIMEOUT_MS / 60000)} menit**`,
    [
      [{ text: "🚀 𝗠𝗨𝗟𝗔𝗜 𝗕𝗨𝗜𝗟𝗗 𝗔𝗣𝗞", data: "build" }, { text: "🌐 𝗪𝗘𝗕 𝗧𝗢 𝗔𝗣𝗞", data: "web2apk" }],
      [{ text: "🏠 𝗠𝗘𝗡𝗨 𝗨𝗧𝗔𝗠𝗔", data: "start" }],
    ],
    deleteMsgId
  );
}

// ─── WEB2APK ─────────────────────────────────────────────────────────────────
async function handleWeb2Apk(chatId, userId, deleteMsgId = null) {
  if (CONFIG.WEB2APK_MAINTENANCE) {
    await send(
      chatId,
      `🛠️ **𝗙𝗜𝗧𝗨𝗥 𝗗𝗔𝗟𝗔𝗠 𝗠𝗔𝗜𝗡𝗧𝗘𝗡𝗔𝗡𝗖𝗘**\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `Mohon maaf, fitur **𝗪𝗘𝗕 𝗧𝗢 𝗔𝗣𝗞** saat ini sedang ditutup sementara untuk peningkatan sistem / perbaikan server.\n\n` +
      `📢 Kami akan menginfokan kembali jika fitur ini sudah dibuka normal melalui channel resmi.\n\n` +
      `__Silakan gunakan fitur Build APK biasa untuk sementara waktu.__`,
      [[{ text: "🏠 𝗠𝗘𝗡𝗨 𝗨𝗧𝗔𝗠𝗔", data: "start" }]],
      deleteMsgId
    );
    return;
  }

  if (isUserBuilding(userId)) {
    const job = getUserJob(userId);
    await send(
      chatId,
      `⚠️ **𝗕𝗨𝗜𝗟𝗗 𝗛𝗔𝗖𝗞 𝗔𝗞𝗧𝗜𝗙!**\n\n` +
      `📋 **Status :** ${statusLabel(job.status)}\n\n` +
      `Harap tunggu hingga selesai, atau batalkan dulu.`,
      [[{ text: "❌ 𝗕𝗔𝗧𝗔𝗟𝗞𝗔𝗡 𝗕𝗨𝗜𝗟𝗗", data: "cancel" }]],
      deleteMsgId
    );
    return;
  }

  let username = null;
  let fullName = "Unknown User";
  try {
    const entity = await client.getEntity(userId);
    username = entity?.username || null;
    fullName =
      [entity?.firstName, entity?.lastName].filter(Boolean).join(" ") ||
      "Unknown User";
  } catch (_) {}

  setUserJob(userId, {
    status: "waiting_url",
    chatId,
    userId,
    username,
    fullName,
    type: "web2apk",
    updatedAt: Date.now(),
  });

  await send(
    chatId,
    `🌐 **𝗪𝗘𝗕 𝗧𝗢 𝗔𝗣𝗞 — 𝗟𝗔𝗡𝗚𝗞𝗔𝗛 1/3**\n` +
    `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
    `Kirim **𝗨𝗥𝗟 𝗪𝗘𝗕𝗦𝗜𝗧𝗘** yang ingin dijadikan APK.\n\n` +
    `📌 Contoh:\n` +
    `\`https://example.com\``,
    [[{ text: "❌ 𝗕𝗔𝗧𝗔𝗟𝗞𝗔𝗡", data: "cancel" }]],
    deleteMsgId
  );
}

async function handleWeb2ApkUrl(event) {
  const chatId = event.chatId;
  const userId = Number(event.message.senderId);
  const text = event.message.text?.trim();
  const job = getUserJob(userId);

  if (!job || job.status !== "waiting_url" || job.type !== "web2apk") return;

  try {
    new URL(text);
  } catch {
    await send(chatId, `❌ **𝗨𝗥𝗟 𝗧𝗜𝗗𝗔𝗞 𝗩𝗔𝗟𝗜𝗗!**\n\nContoh: \`https://example.com\``);
    return;
  }

  setUserJob(userId, { ...job, status: "waiting_appname", webUrl: text, updatedAt: Date.now() });

  await send(
    chatId,
    `✅ **𝗨𝗥𝗟 𝗧𝗘𝗥𝗦𝗜𝗠𝗣𝗔𝗡!**\n\n` +
    `🌐 **𝗪𝗘𝗕 𝗧𝗢 𝗔𝗣𝗞 — 𝗟𝗔𝗡𝗚𝗞𝗔𝗛 2/3**\n` +
    `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
    `Kirim **𝗡𝗔𝗠𝗔 𝗔𝗣𝗟𝗜𝗞𝗔𝗦𝗜** yang diinginkan.\n\n` +
    `📌 Contoh:\n` +
    `\`Toko Online Saya\``,
    [[{ text: "❌ 𝗕𝗔𝗧𝗔𝗟𝗞𝗔𝗡", data: "cancel" }]]
  );
}

async function handleWeb2ApkName(event) {
  const chatId = event.chatId;
  const userId = Number(event.message.senderId);
  const text = event.message.text?.trim();
  const job = getUserJob(userId);

  if (!job || job.status !== "waiting_appname" || job.type !== "web2apk") return;

  setUserJob(userId, { ...job, status: "waiting_icon", appName: text, updatedAt: Date.now() });

  await send(
    chatId,
    `✅ **𝗡𝗔𝗠𝗔 𝗔𝗣𝗣 𝗧𝗘𝗥𝗦𝗜𝗠𝗣𝗔𝗡!**\n\n` +
    `🌐 **𝗪𝗘𝗕 𝗧𝗢 𝗔𝗣𝗞 — 𝗟𝗔𝗡𝗚𝗞𝗔𝗛 3/3**\n` +
    `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
    `Kirim **𝗙𝗢𝗧𝗢/𝗟𝗢𝗚𝗢** untuk icon APK.\n\n` +
    `📌 Tips:\n` +
    `• Kirim sebagai **foto** atau **file gambar**\n` +
    `• Disarankan ukuran **1:1** (persegi)\n` +
    `• Format: PNG, JPG`,
    [[{ text: "❌ 𝗕𝗔𝗧𝗔𝗟𝗞𝗔𝗡", data: "cancel" }]]
  );
}

async function handleWeb2ApkIcon(event) {
  const chatId = event.chatId;
  const userId = Number(event.message.senderId);
  const msg = event.message;
  const job = getUserJob(userId);

  if (!job || job.status !== "waiting_icon" || job.type !== "web2apk") return false;

  const media = msg.media;
  if (!media) return false;

  const isPhoto = media.photo;
  const isDocument = media.document;
  
  if (!isPhoto && !isDocument) {
    await send(chatId, `⚠️ **Kirim ikon dalam bentuk Foto atau File Gambar (𝗣𝗡𝗚/𝗝𝗣𝗚)!**`);
    return true;
  }

  const statusMsg = await send(
    chatId,
    `⚙️ **𝗠𝗘𝗠𝗣𝗥𝗢𝗦𝗘𝗦 𝗪𝗘𝗕 𝗧𝗢 𝗔𝗣𝗞...**\n` +
    `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
    `🌐 **URL  :** \`${job.webUrl}\`\n` +
    `📱 **Nama :** \`${job.appName}\`\n\n` +
    `📥 Mengunduh dan memproses icon...`
  );

  const msgId = statusMsg.id;

  try {
    if (!fs.existsSync(CONFIG.TMP_DIR)) fs.mkdirSync(CONFIG.TMP_DIR, { recursive: true });

    const iconPath = tmpPath(`icon_${userId}_${Date.now()}.png`);
    await client.downloadMedia(msg, { outputFile: iconPath });

    await edit(
      chatId,
      msgId,
      `⚙️ **𝗠𝗘𝗠𝗣𝗥𝗢𝗦𝗘𝗦 𝗪𝗘𝗕 𝗧𝗢 𝗔𝗣𝗞...**\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `🌐 **URL  :** \`${job.webUrl}\`\n` +
      `📱 **Nama :** \`${job.appName}\`\n\n` +
      `☁️ Menyiapkan aset di GitHub Release...`
    );

    const tag = genTag(userId);
    const { releaseId: iconReleaseId, uploadUrl } = await createReleaseOnly(tag);
    
    // Upload asset gambar ke github draft release
    await uploadAssetFile(uploadUrl, iconPath, "icon.png", "image/png");
    if (fs.existsSync(iconPath)) fs.unlinkSync(iconPath);

    const iconUrl = await publishRelease(iconReleaseId);
    console.log("✅ Berhasil Publish! Icon URL:", iconUrl);

    if (!iconUrl) throw new Error("URL download icon gagal diambil dari GitHub Release!");

    const runId = await triggerWeb2ApkWorkflow(job.webUrl, job.appName, iconUrl);

    await edit(
      chatId,
      msgId,
      `⚙️ **𝗠𝗘𝗠𝗣𝗥𝗢𝗦𝗘𝗦 𝗪𝗘𝗕 𝗧𝗢 𝗔𝗣𝗞...**\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `🌐 **URL  :** \`${job.webUrl}\`\n` +
      `📱 **Nama :** \`${job.appName}\`\n\n` +
      `🚀 Memicu workflow server build...`
    );

    setUserJob(userId, {
      ...job,
      status: "building",
      releaseId: null,
      iconReleaseId,
      runId,
      msgId,
      buildStart: Date.now(),
      updatedAt: Date.now(),
    });

    await edit(
      chatId,
      msgId,
      `⚙️ **𝗕𝗨𝗜𝗟𝗗 𝗧𝗢 𝗔𝗣𝗞 𝗥𝗘𝗟𝗘𝗔𝗦𝗘!**\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `🌐 **URL  :** \`${job.webUrl}\`\n` +
      `📱 **Nama :** \`${job.appName}\`\n` +
      `🆔 **Run  :** \`${runId}\`\n\n` +
      `🔄 Memantau progress build...`
    );

    monitorBuild(userId, chatId, msgId, runId, null).catch(async (err) => {
      removeUserJob(userId);
      await edit(chatId, msgId, `❌ **𝗘𝗥𝗥𝗢𝗥 𝗕𝗨𝗜𝗟𝗗 𝗦𝗘𝗥𝗩𝗘𝗥!**\n\n🔴 𝗗𝗘𝗧𝗔𝗜𝗟: \`${err.message}\``);
    });
  } catch (err) {
    removeUserJob(userId);
    await edit(chatId, msgId, `❌ **𝗚𝗔𝗚𝗔𝗟 𝗠𝗘𝗠𝗣𝗥𝗢𝗦𝗘𝗦 𝗔𝗦𝗦𝗘𝗧!**\n\n🔴 Error: \`${err.message}\``);
  }

  return true;
}

// ─── REPORT HANDLING (SISI USER & ADMIN) ─────────────────────────────────────
async function handleUserReportMessages(event) {
  const sender = await event.message.getSender();
  const userId = Number(sender?.id);
  const chatId = event.chatId;
  const messageText = event.message.text;

  const currentState = userStates.get(userId);
  if (!currentState) return false; 

  if (currentState.step === 'WAITING_FOR_REASON') {
    if (!messageText || messageText.length < 10) {
      await client.sendMessage(chatId, { 
        message: "⚠️ **Mohon berikan alasan yang lebih detail (minimal 10 karakter agar admin paham penjelasannya).**",
        buttons: buildButtons([[{ text: "❌ 𝗕𝗔𝗧𝗔𝗟𝗞𝗔𝗡 𝗟𝗔𝗣𝗢𝗥𝗔𝗡", data: "user_cancel_lapor" }]]),
        parseMode: "md"
      });
      return true;
    }
    
    userStates.set(userId, { step: 'WAITING_FOR_SCREENSHOT', reason: messageText });
    await client.sendMessage(chatId, {
      message: `📸 **𝗕𝗨𝗞𝗧𝗜 𝗦𝗖𝗥𝗘𝗘𝗡𝗦𝗛𝗢𝗧**\n\n` +
               `Sekarang, silakan kirimkan **1 Foto/Screenshot** bukti pendukung kendala tersebut untuk mempermudah perbaikan.`,
      parseMode: "md",
      buttons: buildButtons([[{ text: "❌ 𝗕𝗔𝗧𝗔𝗟𝗞𝗔𝗡 𝗟𝗔𝗣𝗢𝗥𝗔𝗡", data: "user_cancel_lapor" }]])
    });
    return true;
  }

  if (currentState.step === 'WAITING_FOR_SCREENSHOT') {
    if (!event.message.media || !(event.message.media instanceof Api.MessageMediaPhoto)) {
      await client.sendMessage(chatId, { 
        message: "⚠️ **Format salah! Silakan kirimkan bukti file berupa Gambar/Foto.**",
        buttons: buildButtons([[{ text: "❌ 𝗕𝗔𝗧𝗔𝗟𝗞𝗔𝗡 𝗟𝗔𝗣𝗢𝗥𝗔𝗡", data: "user_cancel_lapor" }]]),
        parseMode: "md"
      });
      return true;
    }

    const username = sender?.username ? `@${sender.username}` : "Tidak ada username";
    const name = sender?.firstName || "User";
    
    const adminReportLog = 
      `🚨 **𝗟𝗔𝗣𝗢𝗥𝗔𝗡 𝗠𝗔𝗦𝗨𝗞**\n\n` +
      `👤 **Pengirim:** ${name}\n` +
      `🆔 **User ID:** \`${userId}\`\n` +
      `🌐 **Username:** ${username}\n\n` +
      `📝 **Detail Alasan:**\n` +
      `"${currentState.reason}"\n\n` +
      `📌 **Tindakan Admin:**`;

    try {
      const reportIconPath = tmpPath(`report_${userId}_${Date.now()}.jpg`);
      await client.downloadMedia(event.message, { outputFile: reportIconPath });

      await client.sendMessage(CONFIG.CHANNEL_USERNAME, {
        message: adminReportLog,
        file: reportIconPath, 
        parseMode: "md",
        buttons: buildButtons([
          [{ text: "✅ 𝗠𝗔𝗦𝗔𝗟𝗔𝗛 𝗦𝗘𝗟𝗘𝗦𝗔𝗜", data: `adm_fix_${userId}` }],
          [
            { text: "🔒 𝗕𝗟𝗢𝗞𝗜𝗥", data: `adm_blk_${userId}` },
            { text: "🔓 𝗨𝗡𝗕𝗟𝗢𝗞𝗜𝗥", data: `adm_unblk_${userId}` }
          ]
        ])
      });

      if (fs.existsSync(reportIconPath)) fs.unlinkSync(reportIconPath);

      await client.sendMessage(chatId, {
        message: `✅ **Laporan Sukses Dikirim**\n\nTerima kasih, laporan lengkap dan bukti screenshot kamu sudah berhasil masuk ke sistem penanganan admin. Kami akan segera mengeceknya.`,
        parseMode: "md"
      });

    } catch (e) {
      console.error("Gagal mengirim laporan:", e.message);
      await client.sendMessage(chatId, { message: "❌ Terjadi gangguan internal sistem, gagal mengirim laporan." });
    }

    userStates.delete(userId);
    return true;
  }
  return false;
}

// ─── CALLBACK PROCESSING ──────────────────────────────────────────────────────
async function handleCallback(event) {
  try {
    const data = event.data.toString();
    const chatId = event.chatId;
    const userId = Number(event.senderId);
    const msgId = event.messageId;

    if (data === "user_start_lapor") {
      if (db.isReportBlocked(userId)) {
        return event.answer({
          message: "❌ Akses Ditolak! Kamu telah diblokir dari fitur laporan karena terindikasi mengirimkan laporan palsu.",
          alert: true
        });
      }

      userStates.set(userId, { step: 'WAITING_FOR_REASON' });
      await client.editMessage(chatId, {
        message: msgId,
        text: `📝 **𝗠𝗘𝗡𝗨 𝗟𝗔𝗣𝗢𝗥𝗔𝗡**\n\n` +
              `Silakan ketik **𝗔𝗟𝗔𝗦𝗔𝗡 & 𝗗𝗘𝗧𝗔𝗜𝗟 𝗟𝗔𝗣𝗢𝗥𝗔𝗡** kamu dengan jelas, lalu kirimkan lewat chat di bawah ini.\n\n` +
              `⚠️ __Laporan asal-asalan/palsu akan mengakibatkan akun kamu diblokir dari fitur bot.__`,
        parseMode: "md",
        buttons: buildButtons([[{ text: "❌ 𝗕𝗔𝗧𝗔𝗟𝗞𝗔𝗡 𝗟𝗔𝗣𝗢𝗥𝗔𝗡", data: "user_cancel_lapor" }]])
      });
      return await event.answer();
    }

    if (data === "user_cancel_lapor") {
      userStates.delete(userId);
      await client.editMessage(chatId, {
        message: msgId,
        text: `❌ **𝗟𝗔𝗣𝗢𝗥𝗔𝗡 𝗗𝗜𝗕𝗔𝗧𝗔𝗟𝗞𝗔𝗡**\n\nProses pengisian laporan telah dihentikan secara aman. Silakan buka kembali menu utama jika diperlukan.`,
        parseMode: "md",
        buttons: []
      });
      return await event.answer({ message: "Laporan dibatalkan" });
    }

    const isAdminAction = data.startsWith("adm_fix_") || data.startsWith("adm_blk_") || data.startsWith("adm_unblk_");
    if (isAdminAction) {
      if (chatId !== CONFIG.ADMIN_GROUP_ID && !isAdmin(userId)) {
        return await event.answer({ message: "❌ Kamu tidak memiliki akses admin!", alert: true });
      }

      let originalMsgText = "Laporan User";
      try {
        const fullMsg = await client.getMessages(chatId, { ids: [msgId] });
        originalMsgText = fullMsg[0]?.message || fullMsg[0]?.caption || "Laporan User";
      } catch (err) {
        console.error("Gagal get original message:", err);
      }

      if (data.startsWith("adm_fix_")) {
        const targetUserId = Number(data.replace("adm_fix_", ""));
        try {
          await client.sendMessage(targetUserId, {
            message: `🎉 **𝗟𝗔𝗣𝗢𝗥𝗔𝗡 𝗦𝗘𝗟𝗘𝗦𝗔𝗜 𝗗𝗜𝗣𝗥𝗢𝗦𝗘𝗦**\n\n` +
                     `Halo, kendala/bug yang kamu laporkan sebelumnya **𝗧𝗘𝗟𝗔𝗛 𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟 𝗗𝗜 𝗣𝗘𝗥𝗕𝗔𝗜𝗞𝗜** oleh tim admin.\n\n` +
                     `Terima kasih banyak atas kontribusi dan laporan kamu! Silakan dicoba kembali fiturnya.`,
            parseMode: "md"
          });
          await event.answer({ message: "✅ Berhasil memberi tahu user!", alert: false });
        } catch (err) {
          await event.answer({ message: "⚠️ Gagal kirim DM (User memblokir bot)", alert: true });
        }

        await client.editMessage(chatId, {
          message: msgId,
          text: originalMsgText + `\n\n` + `🟢 **𝗦𝗧𝗔𝗧𝗨𝗦:** Selesai diperbaiki & user telah diberitahu.`,
          parseMode: "md",
          buttons: buildButtons([[{ text: "🔒 𝗕𝗟𝗢𝗞𝗜𝗥 𝗨𝗦𝗘𝗥", data: `adm_blk_${targetUserId}` }]])
        });
        return;
      }

      if (data.startsWith("adm_blk_")) {
        const targetUserId = Number(data.replace("adm_blk_", ""));
        if (db.isReportBlocked(targetUserId)) {
          return await event.answer({ message: "ℹ️ User ini sudah berstatus diblokir.", alert: true });
        }
        db.blockReportUser(targetUserId);
        await event.answer({ message: `🔒 ID ${targetUserId} Berhasil Diblokir`, alert: false });

        const cleanedMessage = originalMsgText.replace(`\n\n🟢 **𝗦𝗧𝗔𝗧𝗨𝗦:** Selesai diperbaiki & user telah diberitahu.`, "");
        await client.editMessage(chatId, {
          message: msgId,
          text: cleanedMessage + `\n\n` + `🔴 **𝗦𝗧𝗔𝗧𝗨𝗦:** User telah diblokir oleh admin karena laporan palsu.`,
          parseMode: "md",
          buttons: buildButtons([[{ text: "🔓 𝗨𝗡𝗕𝗟𝗢𝗞𝗜𝗥 𝗨𝗦𝗘𝗥", data: `adm_unblk_${targetUserId}` }]])
        });

        try {
          await client.sendMessage(targetUserId, {
            message: `⚠️ **𝗔𝗞𝗦𝗘𝗦 𝗗𝗜𝗕𝗟𝗢𝗞𝗜𝗥**\n\nFitur laporan kamu telah dinonaktifkan oleh tim admin karena terindikasi mengirimkan laporan palsu/spam.`,
            parseMode: "md"
          });
        } catch (err) {}
        return;
      }

      if (data.startsWith("adm_unblk_")) {
        const targetUserId = Number(data.replace("adm_unblk_", ""));
        if (!db.isReportBlocked(targetUserId)) {
          return await event.answer({ message: "ℹ️ User tidak sedang dalam pemblokiran.", alert: true });
        }
        db.unblockReportUser(targetUserId);
        await event.answer({ message: `🔓 Blokir ID ${targetUserId} Telah Dibuka`, alert: false });

        const cleanedMessage = originalMsgText.replace(`\n\n🔴 **𝗦𝗧𝗔𝗧𝗨𝗦:** User telah diblokir oleh admin karena laporan palsu.`, "");
        await client.editMessage(chatId, {
          message: msgId,
          text: cleanedMessage + `\n\n` + `⚪ **𝗦𝗧𝗔𝗧𝗨𝗦:** Akses laporan dikembangkan normal.`,
          parseMode: "md",
          buttons: buildButtons([
            [{ text: "✅ 𝗠𝗔𝗦𝗔𝗟𝗔𝗛 𝗦𝗘𝗟𝗘𝗦𝗔𝗜", data: `adm_fix_${targetUserId}` }],
            [
              { text: "🔒 𝗕𝗟𝗢𝗜𝗞𝗥", data: `adm_blk_${targetUserId}` },
              { text: "🔓 𝗨𝗡𝗕𝗟𝗢𝗞𝗜𝗥", data: `adm_unblk_${targetUserId}` }
            ]
          ])
        });

        try {
          await client.sendMessage(targetUserId, {
            message: `✅ **𝗔𝗞𝗦𝗘𝗦 𝗗𝗜𝗞𝗘𝗠𝗕𝗔𝗟𝗜𝗞𝗔𝗡**\n\nFitur laporan kamu telah diaktifkan kembali. Mohon gunakan fasilitas ini dengan bijak.`,
            parseMode: "md"
          });
        } catch (err) {}
        return;
      }
    }

    if (data === "check_join") {
      const joined = await isJoinedChannel(userId);

      if (!joined) {
        return event.answer({
          message: "❌ 𝗞𝗔𝗠𝗨 𝗕𝗘𝗟𝗨𝗠 𝗝𝗢𝗜𝗡 𝗦𝗘𝗠𝗨𝗔 𝗖𝗛𝗔𝗡𝗘𝗟 𝗣𝗘𝗣𝗘𝗞!",
          alert: true,
        });
      }

      await event.answer({ message: "✅ 𝗩𝗘𝗥𝗜𝗙𝗜𝗞𝗔𝗦𝗜 𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟 𝗣𝗘𝗣𝗘𝗞!" });

      let firstName = "User";
      try {
        const entity = await client.getEntity(userId);
        firstName = entity?.firstName || "User";
      } catch (_) {}

      return handleStart(
        {
          chatId,
          message: {
            getSender: async () => ({
              id: userId,
              firstName,
              username: null,
            }),
          },
        },
        msgId
      );
    }

    await event.answer();

    if (data === "start") {
      return await handleStart(
        {
          chatId,
          message: {
            getSender: async () => {
              try {
                const entity = await client.getEntity(userId);
                return {
                  id: userId,
                  firstName: entity?.firstName || "User",
                  username: entity?.username || null,
                };
              } catch (_) {
                return { id: userId, firstName: "User" };
              }
            },
          },
        },
        msgId
      );
    }

    if (data === "build") return await handleBuild(chatId, userId, null, msgId);
    if (data === "build_debug") return await handleBuild(chatId, userId, "debug", msgId);
    if (data === "build_release") return await handleBuild(chatId, userId, "release", msgId);
    if (data === "web2apk") return await handleWeb2Apk(chatId, userId, msgId);
    if (data === "obfuscation") return await handleObfuscation(chatId, userId, msgId);
    if (data === "queue") return await handleQueue(chatId, msgId);
    if (data === "help") return await handleHelp(chatId, msgId);
    if (data === "status") return await handleStatus(chatId, userId, msgId);

    if (data === "cancel") {
      removeUserJob(userId);
      return await send(
        chatId,
        `✅ **𝗗𝗜𝗕𝗧𝗔𝗟𝗞𝗔𝗡.**\n\n` +
        `__Ketik /start atau klik tombol di bawah untuk kembali ke menu utama.__`,
        [[{ text: "🏠 𝗠𝗘𝗡𝗨 𝗨𝗧𝗔𝗠𝗔", data: "start" }]],
        msgId
      );
    }
  } catch (err) {
    console.error("handleCallback error:", err);
  }
}

async function handleObfuscation(chatId, userId, deleteMsgId = null) {
  if (isUserBuilding(userId)) {
    const job = getUserJob(userId);
    const elapsed = elapsedSec(job.updatedAt || Date.now());

    return await send(
      chatId,
      `⚠️ **𝗣𝗥𝗢𝗦𝗘𝗦 𝗔𝗖𝗧𝗜𝗙 𝗧𝗘𝗥𝗗𝗘𝗧𝗘𝗞𝗦𝗜!**\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `📋 **Status :** ${statusLabel(job.status)}\n` +
      `⏱ **Berjalan:** ${formatDuration(elapsed)}\n\n` +
      `__Tunggu sampai proses selesai.__`,
      [[{ text: "🔄 𝗥𝗘𝗙𝗥𝗘𝗦𝗛", data: "status" }]],
      deleteMsgId
    );
  }

  setUserJob(userId, { type: "obfuscation", status: "waiting_method" });

  const caption =
    `🔐 **OBFUSCATION CODE GENERATOR** 🔐\n` +
    `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
    `Obfuscation mengubah kode jadi sulit dibaca & dianalisis.\n\n` +
    `**Pilih Metode Obfuscation:**\n\n` +
    `1️⃣ **Standard** - Obfuscation standar tingkat tinggi\n` +
    `2️⃣ **Mandarin** - Variabel Chinese/karakter Mandarin\n` +
    `3️⃣ **Arabic** - Variabel Arabic/karakter Arab\n` +
    `4️⃣ **Japanese** - Variabel Jepang/karakter Hiragana\n` +
    `5️⃣ **Invisible** - Variabel invisible/underscore tersembunyi\n` +
    `6️⃣ **JapanArab Mix** - Kombinasi Jepang & Arab\n` +
    `7️⃣ **X-Style** - Gaya X dengan UUID random\n` +
    `8️⃣ **Nebula** - Enkripsi tingkat tinggi\n` +
    `9️⃣ **Nova** - Perlindungan maksimal+enkripsi\n` +
    `🔟 **SiuCalcrick** - Custom protection\n\n` +
    `**Setelah pilih metode, kirimkan file .js kamu.**\n\n` +
    `__Ketik angka (1-10) untuk memilih metode.__`;

  await send(chatId, caption, [[{ text: "❌ 𝗕𝗔𝗧𝗔𝗟𝗞𝗔𝗡", data: "start" }]], deleteMsgId);
}

async function handleObfuscationMethod(event) {
  const chatId = event.chatId;
  const userId = Number(event.message.senderId);
  const text = event.message.text?.trim();
  const job = getUserJob(userId);

  if (!job || job.type !== "obfuscation" || job.status !== "waiting_method") return;

  const methodMap = {
    "1": "standard", "2": "mandarin", "3": "arabic", "4": "japanese", "5": "invisible",
    "6": "japanarab", "7": "xstyle", "8": "nebula", "9": "nova", "10": "siucalcrick"
  };

  if (!methodMap[text]) {
    return await send(chatId, `⚠️ Pilihan **${text}** tidak valid! Ketik angka **1-10**.`);
  }

  setUserJob(userId, { ...job, status: "waiting_file", method: methodMap[text], updatedAt: Date.now() });

  await send(
    chatId,
    `✅ **Metode: ${methodMap[text].toUpperCase()}** dipilih.\n\n` +
    `📤 Sekarang silakan kirimkan file **.js** yang ingin di-obfuscate.`
  );
}

async function handleObfuscationFile(event) {
  const chatId = event.chatId;
  const userId = Number(event.message.senderId);
  const msg = event.message;
  const job = getUserJob(userId);

  if (!job || job.type !== "obfuscation" || job.status !== "waiting_file") return false;

  const media = msg.media;
  if (!media || !media.document) {
    await send(chatId, `⚠️ Kirim file **.js** ya, bukan teks!`);
    return true;
  }

  const doc = media.document;
  const fileName = doc.attributes?.find((a) => a.fileName)?.fileName || "code.js";

  if (!fileName.endsWith(".js")) {
    await send(chatId, `❌ File harus berformat **.js**, bukan ${fileName.split(".").pop()}!`);
    return true;
  }

  const fileSizeMB = (doc.size / 1024 / 1024).toFixed(1);
  const statusMsg = await send(
    chatId,
    `🔄 **𝗠𝗘𝗠𝗘𝗥𝗠𝗘𝗟𝗔𝗬𝗔 𝗡 𝗩𝗜𝗢𝗕𝗞𝗞𝗔𝗟𝗞𝗜𝗗𝗘𝗡𝗖𝗬 𝗢𝗕𝗙𝗨𝗦𝗖𝗔𝗧𝗜𝗢𝗡...**\n` +
    `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
    `📄 **File  :** \`${fileName}\`\n` +
    `📏 **Ukuran:** \`${fileSizeMB} MB\`\n` +
    `🔐 **Method:** \`${job.method.toUpperCase()}\`\n\n` +
    `⏳ Harap tunggu, sedang diproses...`
  );

  const msgId = statusMsg.id;

  try {
    if (!fs.existsSync(CONFIG.TMP_DIR)) {
      fs.mkdirSync(CONFIG.TMP_DIR, { recursive: true });
    }

    const localFile = tmpPath(`obf_${userId}_${Date.now()}.js`);
    await client.downloadMedia(msg, { outputFile: localFile });

    const codeContent = fs.readFileSync(localFile, "utf-8");
    let obfuscatedCode;

    // Kirim method name (string) bukan config object ke obfuscateCode
    obfuscatedCode = await obfuscateCode(codeContent, job.method);

    const outputFile = tmpPath(`obf_result_${userId}_${Date.now()}.js`);
    fs.writeFileSync(outputFile, obfuscatedCode);

    await edit(
      chatId,
      msgId,
      `✅ **𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟 𝗘𝗡𝗖𝗥𝗬𝗣𝗧!**\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `📄 **File Original :** \`${fileName}\`\n` +
      `🔐 **Method        :** \`${job.method.toUpperCase()}\`\n` +
      `📊 **Ukuran        :** ${fileSizeMB} MB → \`${(outputFile.length / 1024).toFixed(1)} KB\`\n\n` +
      `📥 Sedang mengirim hasil...`
    );

    await client.sendFile(chatId, {
      file: outputFile,
      caption: `🔐 **OBFUSCATED CODE**\n━━━━━━━━━━━━━━━━━━━━━━\n\n📄 File: \`${fileName}\`\n🔐 Method: \`${job.method.toUpperCase()}\`\n✨ Status: Berhasil!\n\n__Kode sudah di-obfuscate dan siap digunakan.__`,
      parseMode: "md"
    });

    fs.unlinkSync(localFile);
    fs.unlinkSync(outputFile);
    removeUserJob(userId);
    db.incrementStat("success");

    await send(chatId, `✅ **𝗥𝗘𝗡𝟰𝗬𝗢𝗨** obfuscation! 🎉\n\n__Klik di bawah untuk kembali ke menu utama atau proses file lain.__`, [[{ text: "🏠 𝗠𝗘𝗡𝗨 𝗨𝗧𝗔𝗠𝗔", data: "start" }]]);
  } catch (err) {
    console.error("Obfuscation error:", err);
    db.incrementStat("failed");
    await edit(
      chatId,
      msgId,
      `❌ **𝗘𝗥𝗥𝗢𝗥!**\n━━━━━━━━━━━━━━━━━━━━━━\n\nTerjadi kesalahan saat obfuscate kode:\n\n${err.message}`
    );
    removeUserJob(userId);
  }

  return true;
}

// ─── MAIN ─────────────────────────────────────────────────────────────────────
async function main() {
  console.log(`🚀 Starting ${CONFIG.BOT_NAME}...`);

  if (!fs.existsSync(CONFIG.TMP_DIR)) fs.mkdirSync(CONFIG.TMP_DIR, { recursive: true });

  await client.start({
    botAuthToken: CONFIG.BOT_TOKEN,
    onError: (err) => console.error("Client error:", err),
  });

  fs.writeFileSync(SESSION_FILE, client.session.save());
  console.log("✅ Bot connected & session saved!");

  client.addEventHandler(async (event) => {
    try {
      const msg = event.message;
      const text = msg?.text?.trim();
      const chatId = event.chatId;
      const userId = Number(msg.senderId);

      if (text === "/start") return handleStart(event);
      if (text === "/help") return handleHelp(chatId);

      if (text?.startsWith("/broadcast") && isAdmin(userId)) {
        const replied = await event.message.getReplyMessage();
        if (!replied) return send(chatId, `⚠️ Reply pesan yang ingin di-broadcast!`);

        await send(chatId, `🚀 **𝗕𝗥𝗢𝗔𝗗𝗖𝗔𝗦𝗧 𝗗𝗜𝗠𝗨𝗟𝗔𝗜...**`);

        const users = db.getAllUsers();
        let success = 0, failed = 0;

        for (const user of users) {
          try {
            if (replied.media) {
              await client.forwardMessages(user.userId, {
                messages: [replied.id],
                fromPeer: replied.chatId,
              });
            } else {
              await send(user.userId, replied.text || replied.caption || "");
            }
            success++;
            await sleep(500);
          } catch (_) {
            failed++;
          }
        }

        return send(
          chatId,
          `✅ **Broadcast Selesai!**\n\n` +
          `✔️ **Sukses :** ${success}\n` +
          `❌ **Gagal  :** ${failed}`
        );
      }

      if (text?.startsWith("/forward") && isAdmin(userId)) {
        const replied = await event.message.getReplyMessage();
        if (!replied) return send(chatId, `⚠️ Reply pesan yang ingin di-forward!`);

        await send(chatId, `🚀 **𝗙𝗢𝗥𝗪𝗔𝗥𝗗 𝗗𝗜𝗠𝗨𝗟𝗔𝗜...**`);

        const users = db.getAllUsers();
        let success = 0, failed = 0;

        for (const user of users) {
          try {
            await client.forwardMessages(user.userId, {
              messages: [replied.id],
              fromPeer: replied.chatId,
            });
            success++;
            await sleep(300);
          } catch (_) {
            failed++;
          }
        }

        return send(
          chatId,
          `✅ **Forward Selesai!**\n\n` +
          `✔️ **Sukses :** ${success}\n` +
          `❌ **Gagal  :** ${failed}`
        );
      }

      const isReportIntercepted = await handleUserReportMessages(event);
      if (isReportIntercepted) return;

      const job = getUserJob(userId);
      if (job?.type === "web2apk") {
        if (job.status === "waiting_url" && text?.startsWith("http"))
          return handleWeb2ApkUrl(event);
        if (job.status === "waiting_appname" && text)
          return handleWeb2ApkName(event);
        if (job.status === "waiting_icon" && msg.media)
          return handleWeb2ApkIcon(event);
      }

      if (job?.type === "obfuscation") {
        if (job.status === "waiting_file" && msg.media)
          return await handleObfuscationFile(event);
        if (job.status === "waiting_method" && text)
          return await handleObfuscationMethod(event);
      }

      if (msg.media) await handleZipFile(event);
    } catch (err) {
      console.error("Handler error:", err);
    }
  }, new NewMessage({}));

  client.addEventHandler(async (event) => {
    try {
      await handleCallback(event);
    } catch (err) {
      console.error("Callback error:", err);
    }
  }, new CallbackQuery({}));

  console.log(`🤖 ${CONFIG.BOT_NAME} v${CONFIG.BOT_VERSION} siap!`);
  await new Promise(() => {});
}

main().catch(console.error);