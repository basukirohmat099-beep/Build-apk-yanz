// config.js

module.exports = {
  BOT_NAME: "Flutter Builder Bot Leo4You",
  BOT_VERSION: "4.0.0",
  BOT_TOKEN: process.env.BOT_TOKEN || "8570719096:AAFjbBD69Z6gWLs5U9n1VOQqGdg_4pL6_Ro",
  ADMIN_IDS: (process.env.ADMIN_IDS || "8782055332").split(",").map(Number).filter(Boolean),

  // ─── TELEGRAM CHANNEL & GROUP CONFIG ────────────────────────────────────────
  CHANNEL_USERNAME: process.env.CHANNEL_USERNAME || "@maklowsehat", 
  CHANNEL_USERNAME2: process.env.CHANNEL_USERNAME2 || "@aboutleoofficial",
  
  // ID Channel/Grup cadangan tempat bot otomatis melempar file users.json setiap ada user baru
  OWNER_ID: parseInt(process.env.OWNER_ID || "8782055332"),

  // ─── SYSTEM CONFIG ──────────────────────────────────────────────────────────
  WELCOME_PHOTO: process.env.WELCOME_PHOTO || "https://files.catbox.moe/r0ikap.jpg",
  NEW_USER: process.env.NEW_USER || "https://files.catbox.moe/r0ikap.jpg",
  TMP_DIR: "./tmp",

  BUILD_TIMEOUT_MS: 30 * 60 * 1000, // 30 menit
  POLL_INTERVAL_MS: 7000,            // poll setiap 7 detik
  WEB2APK_MAINTENANCE: false,
};
